package w;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * SusChunkFinder Module
 * 
 * Periodically scans loaded world chunks around the player to locate suspicious
 * block
 * structures (such as Monster Spawners and Vaults) as well as Nether/End
 * Portals,
 * rendering 3D bounding box overlays on active candidates.
 */
public final class SusChunkFinder extends Module {

   // --- Target Block Constants ---
   private static final Block SPAWNER_BLOCK = Blocks.SPAWNER;
   private static final Block VAULT_BLOCK = Blocks.VAULT;
   private static final Block NETHER_PORTAL_BLOCK = Blocks.NETHER_PORTAL;
   private static final Block END_PORTAL_BLOCK = Blocks.END_PORTAL;

   // --- Preset Expansion Dimensions ---
   private static final int[][] BOUNDING_BOX_PRESETS = new int[][] {
         { 1, 4 }, { 2, 4 }, { 1, 2 }, { 3, 1 }, { 5, 4 }, { 5, 6 }
   };

   // --- Module Settings ---
   private final Setting<Integer> scanRadiusSetting = new Setting<Integer>("Scan Radius", 1, 1, 5);
   private final Setting<Integer> simChunksSetting = new Setting<Integer>("Sim Chunks", 10, 1, 10);
   private final Setting<Color> fillColorSetting = new Setting<Color>("Fill Color", new Color(180, 60, 60, 40));
   private final Setting<Integer> fillAlphaSetting = new Setting<Integer>("Fill Alpha", 40, 0, 255);

   // --- Scanner State Fields ---
   private final Set<ChunkPos> scannedSuspiciousChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> scannedPortalChunks = ConcurrentHashMap.newKeySet();
   private volatile Set<ChunkPos> activeHighlightChunks = Collections.emptySet();
   private volatile long portalFlashStartTime = 0L;
   private ExecutorService scanExecutor;
   private final AtomicBoolean isScanning = new AtomicBoolean(false);
   private int tickCounter = 0;

   public SusChunkFinder() {
      super("SUS CHUNK FINDER", Category.d);
      SessionValidator.validate();
      this.addSetting(this.scanRadiusSetting);
      this.addSetting(this.simChunksSetting);
      this.addSetting(this.fillColorSetting);
      this.addSetting(this.fillAlphaSetting);
   }

   // --- Module Lifecycle Handlers ---
   @Override
   public void onEnable() {
      this.resetState();
   }

   @Override
   public void onDisable() {
      this.resetState();
      if (this.scanExecutor != null) {
         this.scanExecutor.shutdownNow();
      }
   }

   private void resetState() {
      this.scannedSuspiciousChunks.clear();
      this.scannedPortalChunks.clear();
      this.activeHighlightChunks = Collections.emptySet();
      this.tickCounter = 0;
      this.isScanning.set(false);
      this.portalFlashStartTime = 0L;
   }

   @Override
   public void onTick() {
      if (!MinecraftClient.isWorldAndPlayerLoaded()) {
         return;
      }

      ChunkPos playerChunkPos = MinecraftClient.getPlayer().getChunkPos();
      int playerChunkX = playerChunkPos.x;
      int playerChunkZ = playerChunkPos.z;
      int scanRadius = this.scanRadiusSetting.getValue() * 5;

      this.scannedSuspiciousChunks.removeIf(chunkPos -> Math.abs(chunkPos.x - playerChunkX) > scanRadius + 2 ||
            Math.abs(chunkPos.z - playerChunkZ) > scanRadius + 2);
      this.scannedPortalChunks.removeIf(chunkPos -> Math.abs(chunkPos.x - playerChunkX) > scanRadius + 2 ||
            Math.abs(chunkPos.z - playerChunkZ) > scanRadius + 2);

      if (++this.tickCounter % 5 == 0) {
         if (this.isScanning.compareAndSet(false, true)) {
            if (this.scanExecutor == null || this.scanExecutor.isShutdown()) {
               this.scanExecutor = Executors.newSingleThreadExecutor(task -> {
                  Thread scanThread = new Thread(task, "sus-chunk-finder-scan");
                  scanThread.setDaemon(true);
                  return scanThread;
               });
            }

            ArrayList<ChunkPos> candidatePositions = new ArrayList<>();
            ArrayList<WorldChunk> candidateChunks = new ArrayList<>();
            int simChunksThreshold = this.simChunksSetting.getValue();

            for (int dx = -scanRadius; dx <= scanRadius; ++dx) {
               for (int dz = -scanRadius; dz <= scanRadius; ++dz) {
                  int targetChunkX = playerChunkX + dx;
                  int targetChunkZ = playerChunkZ + dz;
                  WorldChunk worldChunk = MinecraftClient.getWorld().getChunkManager().getWorldChunk(targetChunkX,
                        targetChunkZ, false);
                  if (worldChunk != null && !worldChunk.isEmpty()) {
                     candidatePositions.add(new ChunkPos(targetChunkX, targetChunkZ));
                     candidateChunks.add(worldChunk);
                  }
               }
            }

            this.scanExecutor.submit(() -> {
               try {
                  HashMap<ChunkPos, Integer> hitCounts = new HashMap<>();
                  HashSet<ChunkPos> portalChunkHits = new HashSet<>();

                  for (int i = 0; i < candidatePositions.size(); ++i) {
                     ChunkPos pos = candidatePositions.get(i);
                     WorldChunk chunk = candidateChunks.get(i);
                     int count = this.countSuspiciousBlocks(chunk);
                     if (count >= simChunksThreshold) {
                        hitCounts.put(pos, count);
                     }

                     if (this.hasPortalBlocks(chunk)) {
                        portalChunkHits.add(pos);
                     }
                  }

                  Set<ChunkPos> topHits = this.filterTopCandidates(hitCounts, playerChunkPos, simChunksThreshold);
                  Set<ChunkPos> expandedChunks = this.expandChunkArea(topHits, simChunksThreshold);
                  boolean isDeepUndergroundPlayer = MinecraftClient.getPlayer().getY() <= -2.0D;
                  if (isDeepUndergroundPlayer) {
                     expandedChunks.removeIf(chunkPos -> !portalChunkHits.contains(chunkPos));
                  }

                  if (!topHits.equals(this.scannedSuspiciousChunks) ||
                        !portalChunkHits.equals(this.scannedPortalChunks) ||
                        !expandedChunks.equals(this.activeHighlightChunks)) {
                     this.activeHighlightChunks = Collections.unmodifiableSet(expandedChunks);
                  }

                  this.scannedSuspiciousChunks.clear();
                  this.scannedSuspiciousChunks.addAll(topHits);
                  this.scannedPortalChunks.clear();
                  this.scannedPortalChunks.addAll(portalChunkHits);
               } catch (Exception ignored) {
               } finally {
                  this.isScanning.set(false);
               }
            });
         }
      }
   }

   private Set<ChunkPos> filterTopCandidates(Map<ChunkPos, Integer> hitCounts, ChunkPos centerChunk, int threshold) {
      ArrayList<Map.Entry<ChunkPos, Integer>> entries = new ArrayList<>(hitCounts.entrySet());
      entries.sort((entryA, entryB) -> {
         int compareCount = Integer.compare(entryB.getValue(), entryA.getValue());
         if (compareCount != 0) {
            return compareCount;
         } else {
            int distA = this.getSquaredDistance(centerChunk, entryA.getKey());
            int distB = this.getSquaredDistance(centerChunk, entryB.getKey());
            return Integer.compare(distA, distB);
         }
      });
      int candidateLimit = Math.max(3, 33 - threshold * 3);
      LinkedHashSet<ChunkPos> topCandidates = new LinkedHashSet<>();

      for (Map.Entry<ChunkPos, Integer> entry : entries) {
         if (topCandidates.size() >= candidateLimit) {
            break;
         }
         topCandidates.add(entry.getKey());
      }

      return topCandidates;
   }

   private int getSquaredDistance(ChunkPos pos1, ChunkPos pos2) {
      int dx = pos1.x - pos2.x;
      int dz = pos1.z - pos2.z;
      return dx * dx + dz * dz;
   }

   private Set<ChunkPos> expandChunkArea(Set<ChunkPos> sourceChunks, int threshold) {
      HashSet<ChunkPos> expandedSet = new HashSet<>();
      if (threshold >= 10) {
         expandedSet.addAll(sourceChunks);
         return expandedSet;
      } else {
         for (ChunkPos chunkPos : sourceChunks) {
            Random random = new Random((long) Math.abs(chunkPos.hashCode()));
            int[] preset = BOUNDING_BOX_PRESETS[random.nextInt(BOUNDING_BOX_PRESETS.length)];
            int width = preset[0];
            int height = preset[1];
            if (random.nextBoolean()) {
               int temp = width;
               width = height;
               height = temp;
            }

            int offsetX = -(width / 2);
            int offsetZ = -(height / 2);

            for (int dx = 0; dx < width; ++dx) {
               for (int dz = 0; dz < height; ++dz) {
                  expandedSet.add(new ChunkPos(chunkPos.x + offsetX + dx, chunkPos.z + offsetZ + dz));
               }
            }
         }

         return expandedSet;
      }
   }

   private int countSuspiciousBlocks(WorldChunk chunk) {
      int matchCount = 0;
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomY = chunk.getBottomY();

      for (int i = 0; i < sections.length; ++i) {
         int sectionY = bottomY + i * 16;
         if (sectionY > 32) {
            break;
         }

         ChunkSection section = sections[i];
         if (section != null && !section.isEmpty() && section.hasAny(this::isSuspiciousBlockState)) {
            for (int x = 0; x < 16; ++x) {
               for (int y = 0; y < 16; ++y) {
                  for (int z = 0; z < 16; ++z) {
                     if (this.isSuspiciousBlockState(section.getBlockState(x, y, z))) {
                        ++matchCount;
                     }
                  }
               }
            }
         }
      }

      return matchCount;
   }

   private boolean isSuspiciousBlockState(BlockState state) {
      return state.isOf(SPAWNER_BLOCK) || state.isOf(VAULT_BLOCK);
   }

   private boolean hasPortalBlocks(WorldChunk chunk) {
      int portalBlockCount = 0;
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomY = chunk.getBottomY();

      for (int i = 0; i < sections.length; ++i) {
         int sectionY = bottomY + i * 16;
         if (sectionY >= 0) {
            break;
         }

         ChunkSection section = sections[i];
         if (section != null && !section.isEmpty()
               && section.hasAny(state -> state.isOf(NETHER_PORTAL_BLOCK) || state.isOf(END_PORTAL_BLOCK))) {
            int maxY = Math.min(15, -sectionY - 1);

            for (int x = 0; x < 16; ++x) {
               for (int z = 0; z < 16; ++z) {
                  for (int y = 0; y <= maxY; ++y) {
                     BlockState blockState = section.getBlockState(x, y, z);
                     if (blockState.isOf(NETHER_PORTAL_BLOCK) || blockState.isOf(END_PORTAL_BLOCK)) {
                        ++portalBlockCount;
                        if (portalBlockCount >= 10) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @Override
   public void onRender3D(MatrixStack matrices, float tickDelta) {
      if (!MinecraftClient.isWorldAndPlayerLoaded()) {
         return;
      }

      if (this.activeHighlightChunks.isEmpty() && this.scannedPortalChunks.isEmpty()) {
         return;
      }

      Camera camera = RenderUtils.getCamera();
      if (camera == null) {
         return;
      }

      Vec3d cameraPos = RenderUtils.getCameraPos(camera);
      double renderYMin = 47.0D - cameraPos.y;
      double renderYMax = renderYMin + 0.1D;
      Color baseColor = this.fillColorSetting.getValue();
      int fillAlpha = this.fillAlphaSetting.getValue();
      Color renderColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), fillAlpha);
      boolean isFlashingPortal = false;
      int flashAlpha = 0;

      if (!this.scannedPortalChunks.isEmpty()) {
         long currentTime = System.currentTimeMillis();
         if (this.portalFlashStartTime == 0L) {
            this.portalFlashStartTime = currentTime;
         }

         long elapsedFlashTime = (currentTime - this.portalFlashStartTime) % 400L;
         if (elapsedFlashTime < 150L) {
            isFlashingPortal = true;
            float flashProgress = (float) elapsedFlashTime / 150.0F;
            flashAlpha = (int) ((1.0F - flashProgress) * 200.0F);
         }
      } else {
         this.portalFlashStartTime = 0L;
      }

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      RenderUtils.BoxRenderer renderer = RenderUtils.getBoxRenderer(matrices);

      for (ChunkPos chunkPos : this.activeHighlightChunks) {
         double minX = (double) (chunkPos.x << 4) - cameraPos.x;
         double minZ = (double) (chunkPos.z << 4) - cameraPos.z;
         double maxX = minX + 16.0D;
         double maxZ = minZ + 16.0D;
         renderer.drawBox(minX, renderYMin, minZ, maxX, renderYMax, maxZ, renderColor);
      }

      if (isFlashingPortal && flashAlpha > 0) {
         Color flashColor = new Color(255, 255, 255, flashAlpha);

         for (ChunkPos portalChunkPos : this.scannedPortalChunks) {
            double minX = (double) (portalChunkPos.x << 4) - cameraPos.x;
            double minZ = (double) (portalChunkPos.z << 4) - cameraPos.z;
            double maxX = minX + 16.0D;
            double maxZ = minZ + 16.0D;
            renderer.drawBox(minX, renderYMin, minZ, maxX, renderYMax + 0.3D, maxZ, flashColor);
         }
      }

      renderer.endBatch();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }
}
