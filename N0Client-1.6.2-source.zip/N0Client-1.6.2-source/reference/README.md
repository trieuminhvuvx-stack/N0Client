# Supplied SusChunkFinder.java

The supplied `SusChunkFinder.java` is preserved here as a reference. It targets a different
module API (`com.water.module.*`, `com.water.setting.*`, `SessionValidator`, `RenderUtils`)
than this Fabric client, so it is not compiled unchanged. N0Client keeps the existing
SusChunkFinder implementation from the base project, which is already wired into the ClickGUI.
