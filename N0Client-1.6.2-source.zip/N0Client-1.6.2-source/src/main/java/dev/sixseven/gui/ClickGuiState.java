package dev.sixseven.gui;

import com.google.gson.JsonObject;
import dev.sixseven.module.Category;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class ClickGuiState {
   public static final String THEMES_PANEL = "__themes__";
   private final Map<String, PanelState> panels = new LinkedHashMap();
   private final Set<String> expandedModules = new HashSet();
   private boolean laidOut;
   private boolean customized;
   private float lastLayoutWidth = -1.0F;
   private float lastLayoutHeight = -1.0F;
   private static final int LAYOUT_VERSION = 3;
   private static final float PANEL_W = 210.0F;
   private static final float SEARCH_W = 280.0F;

   public void markCustomized() {
      this.customized = true;
   }

   public ClickGuiState() {
      float x = 16.0F;

      for(Category category : Category.values()) {
         this.panels.put(category.name(), new PanelState(x, 16.0F));
         x += 222.0F;
      }

      this.panels.put("__themes__", new PanelState(x, 320.0F));
   }

   public void ensureDefaultLayout(float uiWidth, float uiHeight) {
      if (!this.customized && (!this.laidOut || uiWidth != this.lastLayoutWidth || uiHeight != this.lastLayoutHeight)) {
         this.laidOut = true;
         this.lastLayoutWidth = uiWidth;
         this.lastLayoutHeight = uiHeight;
         String[] order = new String[]{Category.COMBAT.name(), Category.MISC.name(), Category.RENDER.name(), Category.VISUALS.name(), Category.CLIENT.name(), "__themes__"};
         float needed = 1572.0F;
         if (uiWidth >= needed) {
            float gap = (uiWidth - 1260.0F - 280.0F) / 8.0F;
            float x = gap;

            for(int i = 0; i < order.length; ++i) {
               PanelState ps = this.panel(order[i]);
               ps.x = x;
               ps.y = 16.0F;
               ps.collapsed = false;
               x += 210.0F + gap;
               if (i == 2) {
                  x += 280.0F + gap;
               }
            }
         } else {
            float spacing = 222.0F;
            int perRow = Math.max(1, (int)((uiWidth - 24.0F) / spacing));

            for(int i = 0; i < order.length; ++i) {
               PanelState ps = this.panel(order[i]);
               ps.x = 12.0F + (float)(i % perRow) * spacing;
               ps.y = 58.0F + (float)(i / perRow) * uiHeight * 0.44F;
               ps.collapsed = i / perRow > 0;
            }
         }

      }
   }

   public PanelState panel(String key) {
      return (PanelState)this.panels.computeIfAbsent(key, (k) -> new PanelState(16.0F, 16.0F));
   }

   public boolean isExpanded(String moduleKey) {
      return this.expandedModules.contains(moduleKey);
   }

   public void setExpanded(String moduleKey, boolean expanded) {
      if (expanded) {
         this.expandedModules.add(moduleKey);
      } else {
         this.expandedModules.remove(moduleKey);
      }

   }

   public JsonObject toJson() {
      JsonObject json = new JsonObject();
      json.addProperty("v", 3);
      json.addProperty("custom", this.customized);

      for(Map.Entry<String, PanelState> entry : this.panels.entrySet()) {
         JsonObject p = new JsonObject();
         p.addProperty("x", ((PanelState)entry.getValue()).x);
         p.addProperty("y", ((PanelState)entry.getValue()).y);
         p.addProperty("collapsed", ((PanelState)entry.getValue()).collapsed);
         json.add((String)entry.getKey(), p);
      }

      return json;
   }

   public void fromJson(JsonObject json) {
      if (json.has("v") && json.get("v").getAsInt() >= 3) {
         if (json.has("custom") && json.get("custom").getAsBoolean()) {
            this.laidOut = true;
            this.customized = true;

            for(Map.Entry<String, PanelState> entry : this.panels.entrySet()) {
               JsonObject p = json.getAsJsonObject((String)entry.getKey());
               if (p != null) {
                  if (p.has("x")) {
                     ((PanelState)entry.getValue()).x = p.get("x").getAsFloat();
                  }

                  if (p.has("y")) {
                     ((PanelState)entry.getValue()).y = p.get("y").getAsFloat();
                  }

                  if (p.has("collapsed")) {
                     ((PanelState)entry.getValue()).collapsed = p.get("collapsed").getAsBoolean();
                  }
               }
            }

         }
      }
   }

   public static class PanelState {
      public float x;
      public float y;
      public boolean collapsed;

      PanelState(float x, float y) {
         this.x = x;
         this.y = y;
      }
   }
}
