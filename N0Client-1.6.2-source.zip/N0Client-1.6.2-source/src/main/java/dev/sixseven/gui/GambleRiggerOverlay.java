package dev.sixseven.gui;

import dev.sixseven.N0Client;
import dev.sixseven.module.impl.GambleRiggerModule;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screen.ingame.Generic3x3ContainerScreen;

public final class GambleRiggerOverlay {
   private GambleRiggerOverlay() {
   }

   public static void register() {
      ScreenEvents.AFTER_INIT.register((ScreenEvents.AfterInit)(client, screen, scaledWidth, scaledHeight) -> {
         if (screen instanceof Generic3x3ContainerScreen container) {
            GambleRiggerModule mod = N0Client.modules() == null ? null : N0Client.modules().gambleRigger;
            if (mod != null && mod.isEnabled()) {
               GamblePanel panel = new GamblePanel(container, mod);
               ScreenEvents.afterRender(screen).register((ScreenEvents.AfterRender)(s, graphics, mouseX, mouseY, tickDelta) -> panel.render(graphics, mouseX, mouseY));
               ScreenMouseEvents.allowMouseClick(screen).register((ScreenMouseEvents.AllowMouseClick)(s, ctx) -> !panel.handleClick(ctx.x(), ctx.y(), ctx.button()));
            }
         }
      });
   }
}
