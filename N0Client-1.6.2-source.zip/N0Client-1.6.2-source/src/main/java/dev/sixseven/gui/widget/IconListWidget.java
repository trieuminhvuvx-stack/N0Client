package dev.sixseven.gui.widget;

import dev.sixseven.gui.ClickGuiScreen;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.settings.IconListSetting;
import dev.sixseven.theme.Theme;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.Colors;
import dev.sixseven.util.UiSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public class IconListWidget extends SettingWidget {
   private static final float ROW = 26.0F;
   private final IconListSetting setting;

   public IconListWidget(ThemeManager themes, IconListSetting setting) {
      super(themes, setting);
      this.setting = setting;
   }

   public float height(NVGRenderer vg) {
      return 26.0F;
   }

   public void render(NVGRenderer vg, float mx, float my) {
      Theme theme = this.theme();
      float cy = this.y + 13.0F;
      vg.text(this.setting.getName(), this.x, cy, 12.5F, theme.textMuted());
      float bw = 88.0F;
      float bh = 18.0F;
      float bx = this.x + this.width - bw;
      float by = cy - bh / 2.0F;
      boolean hovered = mx >= bx && mx <= bx + bw && my >= by && my <= by + bh;
      vg.rectGradient(bx, by, bw, bh, bh / 2.0F, theme.headerTop(), theme.headerBottom(), true);
      vg.rectOutline(bx, by, bw, bh, bh / 2.0F, 1.1F, Colors.withAlpha(hovered ? theme.accentBright() : theme.accent(), hovered ? 0.9F : 0.4F));
      String label = "Pick";
      float tw = vg.textWidth(label, 12.0F);
      vg.textGradient(label, bx + (bw - tw) / 2.0F, by + bh / 2.0F, 12.0F, theme.accentBright(), theme.accent());
      long var10000 = this.setting.enabledCount();
      String count = var10000 + "/" + this.setting.size();
      vg.text(count, bx - 8.0F - vg.textWidth(count, 11.5F), cy, 11.5F, theme.textDisabled());
   }

   public boolean mouseClicked(float mx, float my, int button) {
      if (button == 0 && this.contains(mx, my)) {
         Screen var5 = MinecraftClient.getInstance().currentScreen;
         if (var5 instanceof ClickGuiScreen) {
            ClickGuiScreen gui = (ClickGuiScreen)var5;
            gui.openIconPicker(this.setting);
            UiSounds.select();
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }
}
