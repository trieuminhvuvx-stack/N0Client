package dev.sixseven.hud;

import com.google.gson.JsonObject;
import dev.sixseven.hud.components.ArmorHud;
import dev.sixseven.hud.components.ArrayListHud;
import dev.sixseven.hud.components.InfoHud;
import dev.sixseven.hud.components.KeystrokesHud;
import dev.sixseven.hud.components.PotionsHud;
import dev.sixseven.hud.components.RadarHud;
import dev.sixseven.hud.components.RegionMapHud;
import dev.sixseven.hud.components.SpotifyHud;
import dev.sixseven.hud.components.StaffListHud;
import dev.sixseven.hud.components.WatermarkHud;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.Modules;
import dev.sixseven.notification.NotificationManager;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.spotify.SpotifyService;
import dev.sixseven.theme.ThemeManager;
import dev.sixseven.util.CpsTracker;
import dev.sixseven.util.TpsTracker;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class HudManager {
   private final List<HudComponent> components = new ArrayList();

   public HudManager(ModuleManager modules, ThemeManager themes, SpotifyService spotify, NotificationManager notifications) {
      Modules.HudModule hud = modules.hud;
      this.components.add(new WatermarkHud(themes, () -> hud.isEnabled() && (Boolean)hud.watermark.get()));
      this.components.add(new ArrayListHud(modules, hud, themes, () -> hud.isEnabled() && (Boolean)hud.arrayList.get()));
      this.components.add(new InfoHud("fps", themes, "FPS", () -> Integer.toString(MinecraftClient.getInstance().getCurrentFps()), 0.006F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.fps.get()));
      this.components.add(new InfoHud("ping", themes, "Ping", HudManager::pingString, 0.055F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.ping.get()));
      this.components.add(new InfoHud("coords", themes, "XYZ", HudManager::coordsString, 0.115F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.coordinates.get()));
      this.components.add(new InfoHud("direction", themes, "Facing", HudManager::directionString, 0.24F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.direction.get()));
      this.components.add(new InfoHud("tps", themes, "TPS", () -> String.format("%.1f", TpsTracker.get()), 0.33F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.tps.get()));
      this.components.add(new InfoHud("cps", themes, "CPS", () -> {
         int var10000 = CpsTracker.get(0);
         return var10000 + " | " + CpsTracker.get(1);
      }, 0.4F, 0.985F, () -> hud.isEnabled() && (Boolean)hud.cps.get()));
      this.components.add(new ArmorHud(themes, () -> hud.isEnabled() && (Boolean)hud.armor.get()));
      this.components.add(new PotionsHud(themes, () -> hud.isEnabled() && (Boolean)hud.potions.get()));
      this.components.add(new KeystrokesHud(themes, () -> hud.isEnabled() && (Boolean)hud.keystrokes.get()));
      this.components.add(new RadarHud(hud, modules.susChunkFinder, themes, () -> hud.isEnabled() && (Boolean)hud.radar.get()));
      this.components.add(new RegionMapHud(modules.regionMap, themes));
      this.components.add(new StaffListHud(modules.staffList, themes));
      this.components.add(new SpotifyHud(modules.spotify, spotify, themes));
      this.components.add(notifications);
   }

   private static String coordsString() {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         return "0, 0, 0";
      } else {
         BlockPos pos = player.getBlockPos();
         int var10000 = pos.getX();
         return var10000 + ", " + pos.getY() + ", " + pos.getZ();
      }
   }

   private static String pingString() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.getNetworkHandler() != null) {
         PlayerListEntry info = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         return info == null ? "0ms" : info.getLatency() + "ms";
      } else {
         return "0ms";
      }
   }

   private static String directionString() {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         return "N";
      } else {
         Direction dir = player.getHorizontalFacing();
         String var10000;
         switch (dir) {
            case NORTH -> var10000 = "N  -Z";
            case SOUTH -> var10000 = "S  +Z";
            case WEST -> var10000 = "W  -X";
            case EAST -> var10000 = "E  +X";
            default -> var10000 = dir.getId().toUpperCase();
         }

         return var10000;
      }
   }

   public List<HudComponent> getComponents() {
      return this.components;
   }

   public List<Placement> layout(NVGRenderer vg, float uiWidth, float uiHeight, boolean includeHidden) {
      List<Placement> placements = new ArrayList();

      for(HudComponent component : this.components) {
         if (includeHidden || component.visible()) {
            float scale = component.getScale();
            float w = component.measureWidth(vg) * scale;
            float h = component.measureHeight(vg) * scale;
            float x = component.getFx() * (uiWidth - w);
            float y = component.getFy() * (uiHeight - h);
            placements.add(new Placement(component, x, y, w, h));
         }
      }

      return placements;
   }

   public void render(NVGRenderer vg, float uiWidth, float uiHeight) {
      for(Placement p : this.layout(vg, uiWidth, uiHeight, false)) {
         this.renderPlacement(vg, p);
      }

   }

   public void renderPlacement(NVGRenderer vg, Placement p) {
      float scale = p.component().getScale();
      vg.save();
      vg.translate((float)Math.round(p.x()), (float)Math.round(p.y()));
      vg.scale(scale);
      p.component().render(vg, 0.0F, 0.0F, p.w() / scale, p.h() / scale);
      vg.restore();
   }

   public JsonObject toJson() {
      JsonObject json = new JsonObject();

      for(HudComponent component : this.components) {
         JsonObject entry = new JsonObject();
         entry.addProperty("fx", component.getFx());
         entry.addProperty("fy", component.getFy());
         entry.addProperty("scale", component.getScale());
         json.add(component.getId(), entry);
      }

      return json;
   }

   public void fromJson(JsonObject json) {
      for(HudComponent component : this.components) {
         JsonObject entry = json.getAsJsonObject(component.getId());
         if (entry != null && entry.has("fx") && entry.has("fy")) {
            component.setPosition(entry.get("fx").getAsFloat(), entry.get("fy").getAsFloat());
            if (entry.has("scale")) {
               component.setScale(entry.get("scale").getAsFloat());
            }
         }
      }

   }

   public static record Placement(HudComponent component, float x, float y, float w, float h) {
      public boolean contains(float px, float py) {
         return px >= this.x && px <= this.x + this.w && py >= this.y && py <= this.y + this.h;
      }
   }
}
