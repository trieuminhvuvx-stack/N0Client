package dev.sixseven.render;

import dev.sixseven.N0Client;
import dev.sixseven.module.impl.ChunkFinderModule;
import dev.sixseven.util.Colors;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class ChunkFinderRenderer {
   private static final float RENDER_Y = 55.0F;
   private static final int FILL_ALPHA = 190;

   private ChunkFinderRenderer() {
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d camera, ChunkFinderModule module) {
      if (!module.flaggedChunks().isEmpty()) {
         int accent = N0Client.themes().current().accent();
         int fill = Colors.withAlpha(Colors.darken(accent, 0.58F), 190);
         int outline = Colors.withAlpha(accent, 255);

         for(long key : module.flaggedChunks()) {
            double x0 = (double)ChunkPos.getPackedX(key) * (double)16.0F;
            double z0 = (double)ChunkPos.getPackedZ(key) * (double)16.0F;
            double x1 = x0 + (double)16.0F;
            double z1 = z0 + (double)16.0F;
            FlatOverlay.fillQuad(bufferSource, poseStack, camera, x0, z0, x1, z1, (double)55.0F, fill);
            FlatOverlay.edge(bufferSource, poseStack, camera, x0, z0, x1, z0, (double)55.0F, outline, 2.0F);
            FlatOverlay.edge(bufferSource, poseStack, camera, x1, z0, x1, z1, (double)55.0F, outline, 2.0F);
            FlatOverlay.edge(bufferSource, poseStack, camera, x1, z1, x0, z1, (double)55.0F, outline, 2.0F);
            FlatOverlay.edge(bufferSource, poseStack, camera, x0, z1, x0, z0, (double)55.0F, outline, 2.0F);
         }

         FlatOverlay.flush(bufferSource);
      }
   }
}
