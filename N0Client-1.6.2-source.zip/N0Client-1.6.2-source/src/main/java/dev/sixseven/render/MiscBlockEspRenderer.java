package dev.sixseven.render;

import dev.sixseven.module.impl.SpawnerNametagsModule;
import dev.sixseven.util.Colors;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3fc;

public final class MiscBlockEspRenderer {
   private static final int SPAWNER_COLOR = -24576;
   private static final double SPAWNER_RANGE = (double)16.0F;
   private static final float TRACER_WIDTH = 1.2F;

   private MiscBlockEspRenderer() {
   }

   public static void renderSpawners(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, SpawnerNametagsModule module) {
      List<BlockPos> snapshot = module.scan.get();
      if (!snapshot.isEmpty()) {
         boolean ring = (Boolean)module.rangeRing.get();
         boolean box = (Boolean)module.box.get();
         boolean tracers = (Boolean)module.tracers.get();
         if (ring || box || tracers) {
            Vector3fc forward = tracers ? MinecraftClient.getInstance().gameRenderer.getCamera().getHorizontalPlane() : null;

            for(BlockPos pos : snapshot) {
               if (box) {
                  EspBoxRenderer.outline(bufferSource, poseStack, cam, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)(pos.getZ() + 1), -24576, 2.0F);
               }

               if (ring) {
                  EspBoxRenderer.ring(bufferSource, poseStack, cam, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F, (double)16.0F, 48, Colors.withAlpha(-24576, 0.6F), 2.0F);
               }

               if (tracers) {
                  EspBoxRenderer.tracer(bufferSource, poseStack, cam, forward, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F, Colors.withAlpha(-24576, 0.7F), 1.2F);
               }
            }

            EspBoxRenderer.flush(bufferSource);
         }
      }
   }
}
