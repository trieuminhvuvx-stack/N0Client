package dev.sixseven.render;

import com.mojang.blaze3d.textures.GpuTexture;
import dev.sixseven.N0Client;
import dev.sixseven.hud.HudDragController;
import dev.sixseven.hud.HudManager;
import dev.sixseven.module.impl.CustomCrosshairModule;
import dev.sixseven.module.impl.MotionBlurModule;
import dev.sixseven.notification.NotificationManager;
import dev.sixseven.render.nanovg.GlStateSnapshot;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.theme.Theme;
import dev.sixseven.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.texture.GlTexture;
import org.lwjgl.opengl.GL33C;

public final class OverlayRenderer {
   private static HudManager hudManager;
   private static NotificationManager notifications;
   private static int fbo = -1;
   private static boolean crashed;

   private OverlayRenderer() {
   }

   public static void init(HudManager hud, NotificationManager toasts) {
      hudManager = hud;
      notifications = toasts;
   }

   public static float uiScale() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return Math.max(1.0F, (float)mc.getWindow().getFramebufferHeight() / 1080.0F);
   }

   public static void render() {
      try {
         GlintTextureTinter.tick();
      } catch (Throwable var19) {
      }

      if (!crashed && hudManager != null) {
         MinecraftClient mc = MinecraftClient.getInstance();
         Framebuffer target = mc.getFramebuffer();
         if (target != null) {
            GpuTexture var3 = target.getColorAttachment();
            if (var3 instanceof GlTexture) {
               GlTexture colorTexture = (GlTexture)var3;
               boolean var22 = mc.currentScreen instanceof NvgDrawable;
               boolean chatEditing = mc.currentScreen instanceof ChatScreen;
               boolean drawHud = !mc.options.hudHidden && mc.world != null && !var22;
               boolean drawToasts = mc.world != null && !mc.options.hudHidden;
               MotionBlurModule mbModule = N0Client.modules() != null ? N0Client.modules().motionBlur : null;
               boolean motionBlur = mbModule != null && mbModule.isEnabled() && mc.world != null && !var22;
               if (!var22 && !drawHud && !drawToasts && !motionBlur) {
                  return;
               }

               try {
                  GlStateSnapshot state = GlStateSnapshot.capture();

                  try {
                     if (bindOverlayFbo(colorTexture, target.textureWidth, target.textureHeight)) {
                        NVGRenderer vg = NVGRenderer.get();
                        if (motionBlur) {
                           MotionBlurRenderer.render(vg, target.textureWidth, target.textureHeight, mbModule);
                        }

                        vg.setFontMode((String)N0Client.modules().clickGui.font.get());
                        if (!vg.hasFont()) {
                           return;
                        }

                        float scale = uiScale();
                        float uiWidth = (float)target.textureWidth / scale;
                        float uiHeight = (float)target.textureHeight / scale;
                        vg.beginFrame((float)target.textureWidth, (float)target.textureHeight, 1.0F);
                        vg.save();
                        vg.scale(scale);
                        if (drawHud) {
                           if (chatEditing && HudDragController.isDragging()) {
                              HudDragController.updateDrag(vg);
                           }

                           CustomCrosshairModule crosshair = N0Client.modules().customCrosshair;
                           if (crosshair.isEnabled() && mc.currentScreen == null) {
                              crosshair.render(vg, uiWidth / 2.0F, uiHeight / 2.0F);
                           }

                           if (mc.currentScreen == null) {
                              WorldNametagRenderer.render(vg);
                           }

                           hudManager.render(vg, uiWidth, uiHeight);
                           if (chatEditing) {
                              renderChatEditOverlay(vg, uiWidth, uiHeight);
                           }
                        }

                        if (drawToasts) {
                           notifications.renderToasts(vg, uiWidth, uiHeight);
                        }

                        if (var22) {
                           ((NvgDrawable)mc.currentScreen).renderNvg(vg, uiMouseX(), uiMouseY(), uiWidth, uiHeight);
                        }

                        vg.restore();
                        vg.endFrame();
                        return;
                     }
                  } finally {
                     state.restore();
                  }

                  return;
               } catch (Throwable t) {
                  crashed = true;
                  N0Client.LOGGER.error("N0Client overlay renderer crashed; disabling overlay", t);
                  return;
               }
            }
         }

      }
   }

   private static void renderChatEditOverlay(NVGRenderer vg, float uiWidth, float uiHeight) {
      Theme theme = N0Client.themes().current();
      float mx = uiMouseX();
      float my = uiMouseY();
      String hint = "Drag to move  \u00b7  scroll to resize";
      vg.text(hint, (uiWidth - vg.textWidth(hint, 14.0F)) / 2.0F, 22.0F, 14.0F, Colors.withAlpha(theme.textMuted(), 0.9F));

      for(HudManager.Placement p : hudManager.layout(vg, uiWidth, uiHeight, true)) {
         boolean hidden = !p.component().visible();
         boolean active = p.contains(mx, my) || p.component() == HudDragController.draggedComponent();
         if (hidden) {
            vg.save();
            vg.alpha(0.35F);
            hudManager.renderPlacement(vg, p);
            vg.restore();
         }

         int outline = active ? theme.accentBright() : Colors.withAlpha(theme.accent(), 0.5F);
         vg.rectOutline(p.x() - 3.0F, p.y() - 3.0F, p.w() + 6.0F, p.h() + 6.0F, 6.0F, active ? 1.6F : 1.0F, outline);
         vg.rect(p.x() + p.w() - 2.0F, p.y() + p.h() - 2.0F, 6.0F, 6.0F, 2.0F, outline);
         if (active) {
            float var10000 = p.component().getScale();
            String pct = Math.round(var10000 * 100.0F) + "%";
            vg.text(pct, p.x() + p.w() + 6.0F, p.y() + p.h() / 2.0F, 11.0F, theme.accentBright());
         }
      }

   }

   private static boolean bindOverlayFbo(GlTexture colorTexture, int width, int height) {
      if (fbo == -1) {
         fbo = GL33C.glGenFramebuffers();
      }

      GL33C.glBindFramebuffer(36160, fbo);
      GL33C.glFramebufferTexture2D(36160, 36064, 3553, colorTexture.getGlId(), 0);
      if (GL33C.glCheckFramebufferStatus(36160) != 36053) {
         return false;
      } else {
         GL33C.glViewport(0, 0, width, height);
         GL33C.glDisable(3089);
         return true;
      }
   }

   public static float uiMouseX() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return (float)(mc.mouse.getX() * (double)mc.getWindow().getFramebufferWidth() / (double)Math.max(1, mc.getWindow().getWidth())) / uiScale();
   }

   public static float uiMouseY() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return (float)(mc.mouse.getY() * (double)mc.getWindow().getFramebufferHeight() / (double)Math.max(1, mc.getWindow().getHeight())) / uiScale();
   }

   public static float guiToUi(double guiCoord) {
      MinecraftClient mc = MinecraftClient.getInstance();
      float pixels = (float)(guiCoord * (double)mc.getWindow().getScaleFactor());
      return pixels / uiScale();
   }

   public static float uiWidth() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return (float)mc.getWindow().getFramebufferWidth() / uiScale();
   }

   public static float uiHeight() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return (float)mc.getWindow().getFramebufferHeight() / uiScale();
   }
}
