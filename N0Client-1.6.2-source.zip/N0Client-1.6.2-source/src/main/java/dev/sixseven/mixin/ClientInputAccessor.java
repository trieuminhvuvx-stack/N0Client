package dev.sixseven.mixin;

import net.minecraft.client.input.Input;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Input.class})
public interface ClientInputAccessor {
   @Accessor("playerInput")
   void n0client$setKeyPresses(PlayerInput var1);

   @Accessor("movementVector")
   void n0client$setMoveVector(Vec2f var1);
}
