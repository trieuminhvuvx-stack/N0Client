package dev.sixseven.mixin;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({KeyBinding.class})
public interface KeyMappingAccessor {
   @Accessor("boundKey")
   InputUtil.Key n0client$getKey();
}
