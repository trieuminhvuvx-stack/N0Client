package dev.sixseven.mixin;

import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.render.AccessoryRenderer;
import dev.sixseven.render.BlockEntityEspRenderer;
import dev.sixseven.render.BlockEspRenderer;
import dev.sixseven.render.BlockOutlineRenderer;
import dev.sixseven.render.ChunkFinderRenderer;
import dev.sixseven.render.EntityEspRenderer;
import dev.sixseven.render.HitParticleRenderer;
import dev.sixseven.render.HoleEspRenderer;
import dev.sixseven.render.JumpCircleRenderer;
import dev.sixseven.render.MiscBlockEspRenderer;
import dev.sixseven.render.StorageEspRenderer;
import dev.sixseven.render.SusChunkRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.OutlineRenderState;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public class LevelRendererMixin {
   @Inject(
      method = {"renderTargetBlockOutline(Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/util/math/MatrixStack;ZLnet/minecraft/client/render/state/WorldRenderState;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$customBlockOutline(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, boolean translucentPass, WorldRenderState levelRenderState, CallbackInfo ci) {
      ModuleManager modules = N0Client.modules();
      if (modules != null) {
         if (translucentPass && modules.susChunkFinder.isEnabled()) {
            SusChunkRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.susChunkFinder);
         }

         if (translucentPass && modules.chunkFinder != null && modules.chunkFinder.isEnabled()) {
            ChunkFinderRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.chunkFinder);
         }

         if (translucentPass && modules.storageEsp != null && modules.storageEsp.isEnabled()) {
            StorageEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.storageEsp);
         }

         if (translucentPass && modules.blockEsp != null && modules.blockEsp.isEnabled()) {
            BlockEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEsp);
         }

         if (translucentPass && modules.blockEntityEsp != null && modules.blockEntityEsp.isEnabled()) {
            BlockEntityEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEntityEsp);
         }

         if (translucentPass && modules.spawnerNametags != null && modules.spawnerNametags.isEnabled()) {
            MiscBlockEspRenderer.renderSpawners(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.spawnerNametags);
         }

         if (translucentPass && modules.debugHoleEsp != null && modules.debugHoleEsp.isEnabled()) {
            HoleEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.debugHoleEsp);
         }

         if (translucentPass && modules.playerEsp != null && modules.playerEsp.isEnabled()) {
            EntityEspRenderer.renderPlayers(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.playerEsp);
         }

         if (translucentPass && modules.mobEsp != null && modules.mobEsp.isEnabled()) {
            EntityEspRenderer.renderMobs(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.mobEsp);
         }

         if (translucentPass && modules.jumpCircles != null && modules.jumpCircles.isEnabled()) {
            JumpCircleRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.jumpCircles);
         }

         if (translucentPass && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            HitParticleRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.hitParticles);
         }

         if (translucentPass && modules.customAccessories != null && modules.customAccessories.isEnabled()) {
            AccessoryRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.customAccessories);
         }

         if (modules.freecam != null && modules.freecam.isActive()) {
            ci.cancel();
         } else if (modules.blockOutline.isEnabled()) {
            ci.cancel();
            OutlineRenderState state = levelRenderState.outlineRenderState;
            if (state != null && state.isTranslucent() == translucentPass) {
               BlockOutlineRenderer.render(bufferSource, poseStack, state, levelRenderState.cameraRenderState.pos, modules.blockOutline);
            }
         }
      }
   }
}
