package dev.sixseven.mixin;

import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerInteractionManager.class})
public class MultiPlayerGameModeAttackMixin {
   @Inject(
      method = {"attackEntity"},
      at = {@At("HEAD")}
   )
   private void n0client$onAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
      if (player == MinecraftClient.getInstance().player && target != player) {
         ModuleManager modules = N0Client.modules();
         if (modules != null && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            modules.hitParticles.onHit(target);
         }

      }
   }
}
