package dev.sixseven.mixin;

import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntity.class})
public class LivingEntityJumpMixin {
   @Inject(
      method = {"jump"},
      at = {@At("HEAD")}
   )
   private void n0client$onJump(CallbackInfo ci) {
      if ((Object)this instanceof ClientPlayerEntity player) {
         if (player == MinecraftClient.getInstance().player) {
            ModuleManager modules = N0Client.modules();
            if (modules != null && modules.jumpCircles != null && modules.jumpCircles.isEnabled()) {
               modules.jumpCircles.onPlayerJump(player);
            }
         }
      }

   }
}
