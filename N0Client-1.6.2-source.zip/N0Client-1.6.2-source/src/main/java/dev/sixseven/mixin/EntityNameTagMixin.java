package dev.sixseven.mixin;

import com.mojang.authlib.GameProfile;
import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.FakeRolesModule;
import dev.sixseven.module.impl.NameTagsModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityRenderer.class})
public class EntityNameTagMixin {
   @Inject(
      method = {"renderLabelIfPresent"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$nameTag(EntityRenderState state, MatrixStack poseStack, OrderedRenderCommandQueue collector, CameraRenderState cameraRenderState, CallbackInfo ci) {
      ModuleManager modules = N0Client.modules();
      if (modules != null && state.displayName != null) {
         NameTagsModule nameTags = modules.nameTags;
         boolean nameTagsOn = nameTags != null && nameTags.isEnabled();
         if (nameTagsOn) {
            String display = state.displayName.getString();
            if (isLocalPlayer(display)) {
               if ((Boolean)nameTags.hideOwnTag.get() || (Boolean)nameTags.players.get() && (Boolean)nameTags.self.get()) {
                  ci.cancel();
                  return;
               }
            } else if (isOnlinePlayer(display)) {
               if ((Boolean)nameTags.players.get() || (Boolean)nameTags.hidePlayerTags.get()) {
                  ci.cancel();
                  return;
               }
            } else if ((Boolean)nameTags.hideOtherTags.get()) {
               ci.cancel();
               return;
            }
         }

         if (modules.nameProtect != null && modules.nameProtect.isEnabled()) {
            String replacement = modules.nameProtect.replacementForDisplay(state.displayName.getString());
            if (replacement != null) {
               state.displayName = Text.literal(replacement);
            }
         }

         FakeRolesModule fakeRoles = modules.fakeRoles;
         if (fakeRoles != null && isLocalPlayer(state.displayName.getString())) {
            state.displayName = fakeRoles.decorateNametag(state.displayName);
         }

      }
   }

   private static boolean isLocalPlayer(String display) {
      if (display != null && !display.isEmpty()) {
         ClientPlayerEntity self = MinecraftClient.getInstance().player;
         if (self == null) {
            return false;
         } else {
            String name = self.getGameProfile().name();
            return name != null && !name.isEmpty() && display.contains(name);
         }
      } else {
         return false;
      }
   }

   private static boolean isOnlinePlayer(String display) {
      if (display != null && !display.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.getNetworkHandler() == null) {
            return false;
         } else {
            for(PlayerListEntry info : mc.getNetworkHandler().getPlayerList()) {
               GameProfile profile = info.getProfile();
               String name = profile == null ? null : profile.name();
               if (name != null && !name.isEmpty() && display.contains(name)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }
}
