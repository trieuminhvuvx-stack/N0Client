package dev.sixseven.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.sixseven.N0Client;
import dev.sixseven.hud.HudDragController;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.util.CpsTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseHandlerMixin {
   @Shadow
   private double cursorDeltaX;
   @Shadow
   private double cursorDeltaY;

   @Inject(
      method = {"updateMouse"},
      at = {@At("HEAD")}
   )
   private void n0client$aimAssist(double d, CallbackInfo ci) {
      ModuleManager modules = N0Client.modules();
      if (modules != null && modules.aimAssist != null && modules.aimAssist.isEnabled()) {
         double[] add = modules.aimAssist.computePixels(d, this.cursorDeltaX, this.cursorDeltaY);
         if (add != null) {
            this.cursorDeltaX += add[0];
            this.cursorDeltaY += add[1];
         }

      }
   }

   @Inject(
      method = {"onMouseButton(JLnet/minecraft/client/input/MouseInput;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$onButton(long window, MouseInput buttonInfo, int action, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (window == minecraft.getWindow().getHandle()) {
         if (action == 1 && minecraft.currentScreen == null) {
            CpsTracker.onClick(buttonInfo.button());
         }

         if (minecraft.currentScreen instanceof ChatScreen && buttonInfo.button() == 0 && N0Client.hud() != null) {
            if (action == 1) {
               if (HudDragController.tryStartDrag(N0Client.hud())) {
                  ci.cancel();
               }
            } else if (action == 0 && HudDragController.isDragging()) {
               HudDragController.stopDrag();
               N0Client.config().save();
               ci.cancel();
            }
         }

      }
   }

   @ModifyExpressionValue(
      method = {"updateMouse"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"
)},
      slice = {@Slice(
   from = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/GameOptions;getMouseSensitivity()Lnet/minecraft/client/option/SimpleOption;"
)
)}
   )
   private Object n0client$zoomSensitivity(Object original) {
      ModuleManager modules = N0Client.modules();
      if (modules != null && modules.zoom != null && original instanceof Double s) {
         double factor = modules.zoom.currentFactor();
         if (factor <= 1.0001) {
            return original;
         } else {
            double e = s * 0.6 + 0.2;
            double scaled = e / Math.cbrt(factor);
            double substitute = (scaled - 0.2) / 0.6;
            return Math.max((double)0.0F, substitute);
         }
      } else {
         return original;
      }
   }

   @Inject(
      method = {"onMouseScroll(JDD)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (window == minecraft.getWindow().getHandle() && minecraft.currentScreen instanceof ChatScreen && N0Client.hud() != null && HudDragController.tryResize(N0Client.hud(), yOffset)) {
         ci.cancel();
      }

   }
}
