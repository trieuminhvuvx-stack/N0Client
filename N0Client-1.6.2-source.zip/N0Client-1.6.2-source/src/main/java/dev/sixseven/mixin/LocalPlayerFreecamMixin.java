package dev.sixseven.mixin;

import dev.sixseven.module.impl.FreecamModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public abstract class LocalPlayerFreecamMixin {
   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void n0client$freecamReapplyBeforeAiStep(CallbackInfo ci) {
      this.n0client$reapply();
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")}
   )
   private void n0client$freecamReapplyBeforeSendPosition(CallbackInfo ci) {
      this.n0client$reapply();
   }

   private void n0client$reapply() {
      ClientPlayerEntity self = (ClientPlayerEntity)(Object)this;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == self) {
         FreecamModule f = FreecamModule.get();
         if (f != null && f.isActive()) {
            FreecamModule.reapplyBodyInput(mc);
         }
      }
   }
}
