package dev.sixseven.mixin;

import dev.sixseven.N0Client;
import dev.sixseven.gui.ClickGuiScreen;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public class KeyboardHandlerMixin {
   @Inject(
      method = {"onKey(JILnet/minecraft/client/input/KeyInput;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$dispatchModuleKeybinds(long window, int action, KeyInput keyEvent, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (N0Client.modules() != null && action == 1) {
         if (minecraft.currentScreen == null && minecraft.world != null) {
            if (N0Client.modules().onKeyPressed(keyEvent.key())) {
               ci.cancel();
            }

         } else {
            if ((keyEvent.key() == 340 || keyEvent.key() == 344) && minecraft.currentScreen != null && shiftOpensGui(minecraft.currentScreen)) {
               minecraft.setScreen(new ClickGuiScreen(minecraft.currentScreen));
               ci.cancel();
            }

         }
      }
   }

   private static boolean shiftOpensGui(Screen screen) {
      if (!(screen instanceof ClickGuiScreen) && !(screen instanceof ChatScreen) && !(screen instanceof HandledScreen) && !(screen instanceof AbstractSignEditScreen) && !(screen instanceof BookEditScreen)) {
         Element var2 = screen.getFocused();
         boolean var10000;
         if (var2 instanceof TextFieldWidget) {
            TextFieldWidget editBox = (TextFieldWidget)var2;
            if (editBox.isFocused()) {
               var10000 = false;
               return var10000;
            }
         }

         var10000 = true;
         return var10000;
      } else {
         return false;
      }
   }
}
