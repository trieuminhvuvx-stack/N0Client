package dev.sixseven.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface MinecraftAccessor {
   @Accessor("itemUseCooldown")
   void n0client$setRightClickDelay(int var1);

   @Invoker("doAttack")
   boolean n0client$startAttack();

   @Invoker("doItemUse")
   void n0client$startUseItem();
}
