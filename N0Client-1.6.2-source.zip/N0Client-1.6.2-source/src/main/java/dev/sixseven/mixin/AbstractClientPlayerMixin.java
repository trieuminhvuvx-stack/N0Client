package dev.sixseven.mixin;

import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.SkinProtectModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayerEntity.class})
public class AbstractClientPlayerMixin {
   @Inject(
      method = {"getSkin"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void n0client$replaceSkin(CallbackInfoReturnable<SkinTextures> cir) {
      ModuleManager modules = N0Client.modules();
      if (modules != null) {
         SkinProtectModule skinProtect = modules.skinProtect;
         if (skinProtect != null && skinProtect.isEnabled()) {
            SkinTextures replacement = skinProtect.replacementSkin();
            if (replacement != null) {
               AbstractClientPlayerEntity self = (AbstractClientPlayerEntity)(Object)this;
               if (skinProtect.shouldReplace(self.getUuid())) {
                  cir.setReturnValue(replacement);
               }

            }
         }
      }
   }
}
