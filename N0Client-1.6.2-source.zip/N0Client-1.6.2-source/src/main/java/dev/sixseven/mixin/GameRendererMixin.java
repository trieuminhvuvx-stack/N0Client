package dev.sixseven.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.FreecamModule;
import dev.sixseven.render.BlurHook;
import dev.sixseven.render.OverlayRenderer;
import dev.sixseven.render.WorldProjection;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GameRenderer.class})
public class GameRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/render/GuiRenderer;incrementFrame()V",
   shift = Shift.AFTER
)}
   )
   private void n0client$renderOverlay(RenderTickCounter deltaTracker, boolean bl, CallbackInfo ci) {
      OverlayRenderer.render();
   }

   @Inject(
      method = {"renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/systems/RenderSystem;setProjectionMatrix(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lcom/mojang/blaze3d/systems/ProjectionType;)V"
)}
   )
   private void n0client$captureProjection(RenderTickCounter deltaTracker, CallbackInfo ci, @Local(ordinal = 0) Matrix4f matrix4f) {
      WorldProjection.capture(matrix4f, deltaTracker.getTickProgress(false));
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gl/GlobalSettings;set(IIDJLnet/minecraft/client/render/RenderTickCounter;ILnet/minecraft/client/render/Camera;Z)V"
),
      index = 5
   )
   private int n0client$overrideBlurRadius(int blurriness) {
      return BlurHook.apply(blurriness);
   }

   @ModifyReturnValue(
      method = {"getFov(Lnet/minecraft/client/render/Camera;FZ)F"},
      at = {@At("RETURN")}
   )
   private float n0client$zoomFov(float original) {
      ModuleManager modules = N0Client.modules();
      if (modules != null && modules.zoom != null) {
         double factor = modules.zoom.currentFactor();
         return factor > 1.0001 ? (float)((double)original / factor) : original;
      } else {
         return original;
      }
   }

   @ModifyExpressionValue(
      method = {"getFov(Lnet/minecraft/client/render/Camera;FZ)F"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F",
   ordinal = 0
)}
   )
   private float n0client$customFov(float sprintMultiplier) {
      ModuleManager modules = N0Client.modules();
      return modules != null && modules.customFov != null ? modules.customFov.fovMultiplier(sprintMultiplier) : sprintMultiplier;
   }

   @ModifyExpressionValue(
      method = {"renderHand"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/Perspective;isFirstPerson()Z"
)}
   )
   private boolean n0client$freecamRenderFirstPersonHands(boolean isFirstPerson) {
      FreecamModule freecam = FreecamModule.get();
      return freecam != null && freecam.isActive() && freecam.renderHands() ? true : isFirstPerson;
   }
}
