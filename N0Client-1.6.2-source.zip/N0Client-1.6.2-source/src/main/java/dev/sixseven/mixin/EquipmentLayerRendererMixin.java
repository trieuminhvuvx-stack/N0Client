package dev.sixseven.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.ArmorTrimHiderModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.trim.ArmorTrim;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({EquipmentRenderer.class})
public class EquipmentLayerRendererMixin {
   @ModifyExpressionValue(
      method = {"render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;II)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/item/ItemStack;method_58694(Lnet/minecraft/component/ComponentType;)Ljava/lang/Object;"
)}
   )
   private Object n0client$armorTrim(Object original, @Local(argsOnly = true) ItemStack itemStack, @Local(argsOnly = true) Object renderState) {
      ModuleManager modules = N0Client.modules();
      if (modules == null) {
         return original;
      } else {
         ArmorTrimHiderModule module = modules.armorTrimHider;
         if (module != null && module.isEnabled()) {
            return !module.affectsOwn() && n0client$isLocalPlayer(renderState) ? original : module.mapTrim(itemStack, (ArmorTrim)original);
         } else {
            return original;
         }
      }
   }

   private static boolean n0client$isLocalPlayer(Object renderState) {
      if (!(renderState instanceof PlayerEntityRenderState avatar)) {
         return false;
      } else {
         MinecraftClient mc = MinecraftClient.getInstance();
         return mc.player != null && avatar.id == mc.player.getId();
      }
   }
}
