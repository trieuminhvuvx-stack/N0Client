package dev.sixseven.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.sixseven.N0Client;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.module.impl.FreecamModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public class GuiCrosshairMixin {
   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$hideVanillaCrosshair(DrawContext guiGraphics, RenderTickCounter deltaTracker, CallbackInfo ci) {
      ModuleManager modules = N0Client.modules();
      if (modules != null && modules.customCrosshair != null && modules.customCrosshair.shouldHideVanilla()) {
         ci.cancel();
      }

   }

   @ModifyExpressionValue(
      method = {"renderCrosshair"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/Perspective;isFirstPerson()Z"
)}
   )
   private boolean n0client$freecamCrosshairInThirdPerson(boolean isFirstPerson) {
      FreecamModule freecam = FreecamModule.get();
      return freecam != null && freecam.isActive() && freecam.isShowPlayerModel() && !isFirstPerson ? true : isFirstPerson;
   }
}
