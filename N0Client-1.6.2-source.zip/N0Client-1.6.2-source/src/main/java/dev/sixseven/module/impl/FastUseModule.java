package dev.sixseven.module.impl;

import dev.sixseven.mixin.MinecraftAccessor;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class FastUseModule extends Module {
   public final ModeSetting items = (ModeSetting)this.addSetting(new ModeSetting("Items", "What to speed up", "All", new String[]{"All", "Pearls", "XP Bottles"}));

   public FastUseModule() {
      super("FastUse", "Removes item use cooldowns", Category.MISC);
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if (this.appliesTo(mc)) {
            ((MinecraftAccessor)mc).n0client$setRightClickDelay(0);
         }
      }
   }

   private boolean appliesTo(MinecraftClient mc) {
      if (this.items.is("All")) {
         return true;
      } else {
         Item target = this.items.is("Pearls") ? Items.ENDER_PEARL : Items.EXPERIENCE_BOTTLE;
         return mc.player.getMainHandStack().isOf(target) || mc.player.getOffHandStack().isOf(target);
      }
   }
}
