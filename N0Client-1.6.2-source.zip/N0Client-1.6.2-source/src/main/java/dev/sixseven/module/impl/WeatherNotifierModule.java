package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.notification.NotificationManager;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;

public class WeatherNotifierModule extends Module {
   public final BooleanSetting rain = (BooleanSetting)this.addSetting(new BooleanSetting("Rain", "Announce when rain starts/stops", true));
   public final BooleanSetting thunder = (BooleanSetting)this.addSetting(new BooleanSetting("Thunder", "Announce when a thunderstorm starts/stops", true));
   public final BooleanSetting sound = (BooleanSetting)this.addSetting(new BooleanSetting("Sound", "Play a ping on each change", true));
   public final ModeSetting output = (ModeSetting)this.addSetting(new ModeSetting("Output", "How the change is shown", "Notification", new String[]{"Notification", "Chat", "Action Bar"}));
   private Boolean lastRaining;
   private Boolean lastThundering;

   public WeatherNotifierModule() {
      super("WeatherNotifier", "Themed toast when the weather changes", Category.MISC);
   }

   protected void onEnable() {
      this.lastRaining = null;
      this.lastThundering = null;
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      World level = mc.world;
      if (level != null && mc.player != null) {
         boolean raining = level.isRaining();
         boolean thundering = level.isThundering();
         if (this.lastRaining != null && this.lastThundering != null) {
            if (thundering != this.lastThundering) {
               this.lastThundering = thundering;
               if ((Boolean)this.thunder.get()) {
                  if (thundering) {
                     this.notify(mc, "Thunderstorm", "A storm rolls in", NotificationManager.Weather.THUNDER, true);
                  } else {
                     this.notify(mc, "Storm cleared", "The thunder has passed", NotificationManager.Weather.CLEAR, false);
                  }
               }
            }

            if (raining != this.lastRaining) {
               this.lastRaining = raining;
               if ((Boolean)this.rain.get() && !thundering) {
                  if (raining) {
                     this.notify(mc, "Rain", "Rain starts to fall", NotificationManager.Weather.RAIN, true);
                  } else {
                     this.notify(mc, "Skies cleared", "The rain has stopped", NotificationManager.Weather.CLEAR, false);
                  }
               }
            }

         } else {
            this.lastRaining = raining;
            this.lastThundering = thundering;
         }
      }
   }

   private void notify(MinecraftClient mc, String title, String subtitle, NotificationManager.Weather weather, boolean started) {
      if (mc.player != null) {
         if (this.output.is("Notification")) {
            if (N0Client.notifications() != null) {
               N0Client.notifications().pushWeather(title, subtitle, weather, started);
            }
         } else {
            boolean actionBar = this.output.is("Action Bar");
            mc.player.sendMessage(Text.literal("\u00a7d[67] \u00a7f" + title + " \u2014 " + subtitle), actionBar);
         }

         if ((Boolean)this.sound.get()) {
            float pitch = started ? 1.2F : 0.8F;
            mc.getSoundManager().play(PositionedSoundInstance.ui((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), pitch, 0.6F));
         }

      }
   }
}
