package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.SliderSetting;
import dev.sixseven.util.InventoryHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

public class AutoTotemModule extends Module {
   public final SliderSetting delay = (SliderSetting)this.addSetting(new SliderSetting("Delay", "", (double)4.0F, (double)1.0F, (double)40.0F, (double)1.0F));
   public final BooleanSetting forceTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Force Totem", "", false));
   public final BooleanSetting hotbarTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Hotbar Totem", "", false));
   public final SliderSetting hotbarSlot = (SliderSetting)this.addSetting(new SliderSetting("Hotbar Slot", "", (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   public final SliderSetting hotbarDelay = (SliderSetting)this.addSetting(new SliderSetting("Hotbar Delay", "", (double)4.0F, (double)1.0F, (double)40.0F, (double)1.0F));
   private int tickCounter;
   private int pendingHotbarSlot = -1;

   public AutoTotemModule() {
      super("Auto Totem", "Totem to offhand/hotbar \u2014 hotbar select + F swap (+ SWAP from main inv when needed)", Category.COMBAT);
   }

   protected void onEnable() {
      this.tickCounter = 0;
      this.pendingHotbarSlot = -1;
   }

   protected void onDisable() {
      this.tickCounter = 0;
      this.pendingHotbarSlot = -1;
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null) {
         if (canRun(client)) {
            ++this.tickCounter;
            int wait = (Boolean)this.hotbarTotem.get() && this.needsHotbarWork(client) && !this.needsOffhandWork(client) ? this.hotbarDelay.getInt() : this.delay.getInt();
            if (this.tickCounter >= wait) {
               this.tickCounter = 0;
               ClientPlayerEntity player = client.player;
               int configuredHotbar = this.hotbarSlot.getInt() - 1;
               if ((Boolean)this.hotbarTotem.get() && this.needsHotbarWork(client)) {
                  if (player.getInventory().getStack(configuredHotbar).isOf(Items.TOTEM_OF_UNDYING)) {
                     InventoryHelper.selectHotbarSlot(configuredHotbar);
                  } else {
                     int source = findTotemInMainInventory(client);
                     if (source != -1 && canContainerClick(client)) {
                        InventoryHelper.swapInventoryToHotbar(source, configuredHotbar);
                     }
                  }
               } else if (!this.needsOffhandWork(client)) {
                  this.pendingHotbarSlot = -1;
               } else if (!player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) || (Boolean)this.forceTotem.get()) {
                  int hotbarTotemSlot = findTotemInHotbar(client);
                  if (hotbarTotemSlot != -1) {
                     this.pendingHotbarSlot = hotbarTotemSlot;
                     InventoryHelper.selectHotbarSlot(hotbarTotemSlot);
                     if (player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                        InventoryHelper.swapOffhand();
                     }
                  } else if (this.pendingHotbarSlot >= 0) {
                     InventoryHelper.selectHotbarSlot(this.pendingHotbarSlot);
                     if (player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                        InventoryHelper.swapOffhand();
                        this.pendingHotbarSlot = -1;
                     }
                  } else {
                     int mainInvTotem = findTotemInMainInventory(client);
                     if (mainInvTotem != -1 && canContainerClick(client)) {
                        int targetHotbar = configuredHotbar;
                        if (!(Boolean)this.hotbarTotem.get()) {
                           targetHotbar = player.getInventory().getSelectedSlot();
                        }

                        InventoryHelper.swapInventoryToHotbar(mainInvTotem, targetHotbar);
                        this.pendingHotbarSlot = targetHotbar;
                     } else if (player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                        InventoryHelper.swapOffhand();
                     }
                  }
               }

            }
         }
      }
   }

   private static boolean canRun(MinecraftClient client) {
      return client.currentScreen == null || client.currentScreen instanceof InventoryScreen;
   }

   private static boolean canContainerClick(MinecraftClient client) {
      return client.currentScreen != null || !isMoving(client);
   }

   private static boolean isMoving(MinecraftClient client) {
      if (client.player == null) {
         return false;
      } else if (!client.options.forwardKey.isPressed() && !client.options.backKey.isPressed() && !client.options.leftKey.isPressed() && !client.options.rightKey.isPressed() && !client.options.jumpKey.isPressed() && !client.player.isSprinting() && !client.player.isSneaking()) {
         double vx = client.player.getVelocity().x;
         double vz = client.player.getVelocity().z;
         return vx * vx + vz * vz > 0.0025;
      } else {
         return true;
      }
   }

   private boolean needsOffhandWork(MinecraftClient client) {
      boolean hasTotemOffhand = client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
      return (Boolean)this.forceTotem.get() || !hasTotemOffhand;
   }

   private boolean needsHotbarWork(MinecraftClient client) {
      if (!(Boolean)this.hotbarTotem.get()) {
         return false;
      } else {
         int slot = this.hotbarSlot.getInt() - 1;
         return !client.player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING);
      }
   }

   private static int findTotemInMainInventory(MinecraftClient client) {
      for(int i = 9; i < 36; ++i) {
         if (client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
            return i;
         }
      }

      return -1;
   }

   private static int findTotemInHotbar(MinecraftClient client) {
      for(int i = 0; i < 9; ++i) {
         if (client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
            return i;
         }
      }

      return -1;
   }
}
