package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.module.ModuleManager;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ColorSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.StringSetting;
import dev.sixseven.util.Amounts;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

public class FakePayModule extends Module {
   private static final int WHITE = 16777215;
   private static final int RED = 16733525;
   public final StringSetting command = (StringSetting)this.addSetting(new StringSetting("Command", "Command name to hijack, without the slash.", "pay", 32, "pay"));
   public final ModeSetting feedback = (ModeSetting)this.addSetting(new ModeSetting("Feedback", "Where the confirmation shows.", "Both", new String[]{"Both", "Action Bar", "Chat"}));
   public final StringSetting currency = (StringSetting)this.addSetting(new StringSetting("Currency", "Symbol before the amount (colored).", "$", 4, "$"));
   public final ColorSetting currencyColor = (ColorSetting)this.addSetting(new ColorSetting("Currency Color", "Color of the currency symbol (DonutSMP blue by default).", -16740609));
   public final BooleanSetting sounds = (BooleanSetting)this.addSetting(new BooleanSetting("Sounds", "Level-up on success, villager 'no' when it fails.", true));
   public final BooleanSetting checkBalance = (BooleanSetting)this.addSetting(new BooleanSetting("Check Balance", "With FakeStats on, refuse pays you can't afford.", true));
   public final BooleanSetting selfGuard = (BooleanSetting)this.addSetting(new BooleanSetting("Self-Pay Guard", "Block paying your own name, like the real command.", true));

   public FakePayModule() {
      super("FakePay", "Fakes a /pay for clips \u2014 blocks the real command", Category.MISC);
   }

   public boolean tryIntercept(String rawCommand) {
      if (this.isEnabled() && rawCommand != null) {
         String[] parts = rawCommand.trim().split("\\s+");
         if (parts.length == 0) {
            return false;
         } else {
            String name = parts[0];
            if (name.startsWith("/")) {
               name = name.substring(1);
            }

            String target = ((String)this.command.get()).trim();
            if (!target.isEmpty() && name.equalsIgnoreCase(target)) {
               this.handle(parts);
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void handle(String[] parts) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if (parts.length < 3) {
            this.show(mc, Text.literal("Usage: /" + parts[0] + " <player> <amount>").withColor(16733525));
            this.fail(mc);
         } else {
            String player = parts[1];
            double amount = Amounts.parse(parts[2]);
            if (!Double.isNaN(amount) && !(amount <= (double)0.0F)) {
               if ((Boolean)this.selfGuard.get() && player.equalsIgnoreCase(mc.player.getGameProfile().name())) {
                  this.show(mc, Text.literal("You can't pay yourself!").withColor(16733525));
                  this.fail(mc);
               } else {
                  FakeStatsModule stats = this.stats();
                  boolean useStats = stats != null && stats.isEnabled() && (Boolean)stats.deductOnPay.get();
                  if (useStats && (Boolean)this.checkBalance.get() && stats.getLiveBalance() < amount) {
                     this.show(mc, Text.literal("You don't have enough money!").withColor(16733525));
                     this.fail(mc);
                  } else {
                     if (useStats) {
                        stats.deduct(amount);
                     }

                     MutableText line = Text.empty().append(Text.literal("You paid " + player).withColor(16777215));
                     String symbol = (String)this.currency.get();
                     if (!symbol.isEmpty()) {
                        line.append(Text.literal(" " + symbol).withColor((Integer)this.currencyColor.get() & 16777215)).append(Text.literal(Amounts.shortForm(amount)).withColor(16777215));
                     } else {
                        line.append(Text.literal(" " + Amounts.shortForm(amount)).withColor(16777215));
                     }

                     this.show(mc, line);
                     this.succeed(mc);
                  }
               }
            } else {
               this.show(mc, Text.literal("Invalid amount: " + parts[2]).withColor(16733525));
               this.fail(mc);
            }
         }
      }
   }

   private void show(MinecraftClient mc, Text component) {
      if (mc.player != null) {
         String mode = (String)this.feedback.get();
         if (mode.equals("Action Bar") || mode.equals("Both")) {
            mc.player.sendMessage(component, true);
         }

         if (mode.equals("Chat") || mode.equals("Both")) {
            mc.player.sendMessage(component, false);
         }

      }
   }

   private void succeed(MinecraftClient mc) {
      if ((Boolean)this.sounds.get()) {
         this.play(mc, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0F);
      }

   }

   private void fail(MinecraftClient mc) {
      if ((Boolean)this.sounds.get()) {
         this.play(mc, SoundEvents.ENTITY_VILLAGER_NO, 1.0F);
      }

   }

   private void play(MinecraftClient mc, SoundEvent event, float pitch) {
      mc.getSoundManager().play(PositionedSoundInstance.ui(event, pitch, 1.0F));
   }

   private FakeStatsModule stats() {
      ModuleManager modules = N0Client.modules();
      return modules == null ? null : modules.fakeStats;
   }
}
