package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.render.BlockScanCache;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.SliderSetting;
import net.minecraft.block.Blocks;

public class SpawnerNametagsModule extends Module {
   public final BooleanSetting nametag = (BooleanSetting)this.addSetting(new BooleanSetting("Nametag", "Floating type + distance label", true));
   public final BooleanSetting box = (BooleanSetting)this.addSetting(new BooleanSetting("Box", "Through-wall box on the spawner", true));
   public final BooleanSetting rangeRing = (BooleanSetting)this.addSetting(new BooleanSetting("Range Ring", "Draw the 16-block activation ring", true));
   public final BooleanSetting distance = (BooleanSetting)this.addSetting(new BooleanSetting("Distance", "Append the distance in blocks", true));
   public final SliderSetting opacity = (SliderSetting)this.addSetting(new SliderSetting("Opacity", "Nametag transparency", (double)100.0F, (double)10.0F, (double)100.0F, (double)5.0F, "%"));
   public final BooleanSetting tracers = (BooleanSetting)this.addSetting(new BooleanSetting("Tracers", "Draw lines from the crosshair to each spawner", false));
   public final BlockScanCache scan = new BlockScanCache((state) -> state.isOf(Blocks.SPAWNER) || state.isOf(Blocks.TRIAL_SPAWNER), 12, 8, 400, (double)96.0F);

   public SpawnerNametagsModule() {
      super("SpawnerNametags", "Shows spawner type + activation range", Category.RENDER);
   }

   public void onTick() {
      this.scan.scan();
   }

   protected void onDisable() {
      this.scan.clear();
   }
}
