package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ColorSetting;
import dev.sixseven.settings.ModeSetting;

public class PlayerEspModule extends Module {
   public final ModeSetting style = (ModeSetting)this.addSetting(new ModeSetting("Style", "Highlight style", "Outline", new String[]{"Box", "Outline", "Glow"}));
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Highlight color", -49508));
   public final BooleanSetting tracers = (BooleanSetting)this.addSetting(new BooleanSetting("Tracers", "Draw lines from the crosshair to each player", false));

   public PlayerEspModule() {
      super("PlayerESP", "Highlights players through walls", Category.RENDER);
   }
}
