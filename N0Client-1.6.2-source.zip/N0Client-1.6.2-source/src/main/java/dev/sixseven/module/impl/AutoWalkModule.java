package dev.sixseven.module.impl;

import dev.sixseven.mixin.KeyMappingAccessor;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Type;

public class AutoWalkModule extends Module {
   public final ModeSetting mode = (ModeSetting)this.addSetting(new ModeSetting("Mode", "Walking mode.", "Simple", new String[]{"Simple", "Smart"}));
   public final ModeSetting direction = (ModeSetting)this.addSetting(new ModeSetting("Direction", "The direction to walk in Simple mode.", "Forwards", new String[]{"Forwards", "Backwards", "Left", "Right"}));
   public final BooleanSetting disableOnInput = (BooleanSetting)this.addSetting(new BooleanSetting("Disable On Input", "Disable the module on manual movement input.", false));
   public final BooleanSetting disableOnY = (BooleanSetting)this.addSetting(new BooleanSetting("Disable On Y Change", "Disable the module if you move vertically.", false));
   public final BooleanSetting waitForChunks = (BooleanSetting)this.addSetting(new BooleanSetting("No Unloaded Chunks", "Do not walk into unloaded chunks.", true));

   public AutoWalkModule() {
      super("AutoWalk", "Automatically walks forward.", Category.MISC);
      this.direction.visibleWhen(() -> this.mode.is("Simple"));
      this.disableOnY.visibleWhen(() -> this.mode.is("Simple"));
      this.waitForChunks.visibleWhen(() -> this.mode.is("Simple"));
   }

   protected void onDisable() {
      this.release(MinecraftClient.getInstance());
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.world != null) {
         this.release(mc);
         if (this.mode.is("Smart")) {
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
            if (mc.player.horizontalCollision && mc.player.isOnGround()) {
               mc.options.jumpKey.setPressed(true);
            }

         } else if ((Boolean)this.disableOnY.get() && mc.player.lastY != mc.player.getY()) {
            this.toggle();
         } else if (!(Boolean)this.waitForChunks.get() || this.chunkAheadLoaded(mc)) {
            String var2 = (String)this.direction.get();
            byte var3 = -1;
            switch (var2.hashCode()) {
               case -934227760:
                  if (var2.equals("Backwards")) {
                     var3 = 1;
                  }
                  break;
               case 2364455:
                  if (var2.equals("Left")) {
                     var3 = 2;
                  }
                  break;
               case 78959100:
                  if (var2.equals("Right")) {
                     var3 = 3;
                  }
                  break;
               case 547957358:
                  if (var2.equals("Forwards")) {
                     var3 = 0;
                  }
            }

            switch (var3) {
               case 0 -> mc.options.forwardKey.setPressed(true);
               case 1 -> mc.options.backKey.setPressed(true);
               case 2 -> mc.options.leftKey.setPressed(true);
               case 3 -> mc.options.rightKey.setPressed(true);
            }

         }
      } else {
         this.release(mc);
      }
   }

   public boolean onKeyPress(int keyCode) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if ((Boolean)this.disableOnInput.get() && mc.currentScreen == null && this.isMovementKey(mc, keyCode)) {
         this.toggle();
      }

      return false;
   }

   private boolean chunkAheadLoaded(MinecraftClient mc) {
      double yawRad = Math.toRadians((double)mc.player.getYaw());
      double fx = -Math.sin(yawRad);
      double fz = Math.cos(yawRad);
      String var12 = (String)this.direction.get();
      int bz = -1;
      switch (var12.hashCode()) {
         case -934227760:
            if (var12.equals("Backwards")) {
               bz = 0;
            }
            break;
         case 2364455:
            if (var12.equals("Left")) {
               bz = 1;
            }
            break;
         case 78959100:
            if (var12.equals("Right")) {
               bz = 2;
            }
      }

      double dx;
      double dz;
      switch (bz) {
         case 0:
            dx = -fx;
            dz = -fz;
            break;
         case 1:
            dx = -fz;
            dz = fx;
            break;
         case 2:
            dx = fz;
            dz = -fx;
            break;
         default:
            dx = fx;
            dz = fz;
      }

      int bx = (int)Math.floor(mc.player.getX() + dx * (double)2.0F);
      bz = (int)Math.floor(mc.player.getZ() + dz * (double)2.0F);
      return mc.world.getChunkManager().isChunkLoaded(bx >> 4, bz >> 4);
   }

   private void release(MinecraftClient mc) {
      if (mc.options != null) {
         mc.options.forwardKey.setPressed(false);
         mc.options.backKey.setPressed(false);
         mc.options.leftKey.setPressed(false);
         mc.options.rightKey.setPressed(false);
         mc.options.jumpKey.setPressed(false);
         mc.options.sprintKey.setPressed(false);
      }
   }

   private boolean isMovementKey(MinecraftClient mc, int keyCode) {
      GameOptions o = mc.options;
      return matches(o.forwardKey, keyCode) || matches(o.backKey, keyCode) || matches(o.leftKey, keyCode) || matches(o.rightKey, keyCode) || matches(o.jumpKey, keyCode) || matches(o.sneakKey, keyCode);
   }

   private static boolean matches(KeyBinding km, int keyCode) {
      InputUtil.Key key = ((KeyMappingAccessor)km).n0client$getKey();
      return key.getCategory() == Type.KEYSYM && key.getCode() == keyCode;
   }
}
