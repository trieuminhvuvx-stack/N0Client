package dev.sixseven.module.impl;

import dev.sixseven.mixin.MinecraftAccessor;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import net.minecraft.client.MinecraftClient;

public class AutoClickerModule extends Module {
   public final BooleanSetting inScreens = (BooleanSetting)this.addSetting(new BooleanSetting("While In Screens", "Whether to click while a screen is open.", true));
   public final ModeSetting leftMode = (ModeSetting)this.addSetting(new ModeSetting("Left Click Mode", "The method of clicking for left clicks.", "Press", new String[]{"Disabled", "Hold", "Press"}));
   public final SliderSetting leftDelay = (SliderSetting)this.addSetting(new SliderSetting("Left Click Delay", "Delay between left clicks in ticks.", (double)2.0F, (double)0.0F, (double)60.0F, (double)1.0F, " ticks"));
   public final ModeSetting rightMode = (ModeSetting)this.addSetting(new ModeSetting("Right Click Mode", "The method of clicking for right clicks.", "Press", new String[]{"Disabled", "Hold", "Press"}));
   public final SliderSetting rightDelay = (SliderSetting)this.addSetting(new SliderSetting("Right Click Delay", "Delay between right clicks in ticks.", (double)2.0F, (double)0.0F, (double)60.0F, (double)1.0F, " ticks"));
   private int leftTimer;
   private int rightTimer;

   public AutoClickerModule() {
      super("AutoClicker", "Automatically clicks.", Category.MISC);
      this.leftDelay.visibleWhen(() -> this.leftMode.is("Press"));
      this.rightDelay.visibleWhen(() -> this.rightMode.is("Press"));
   }

   protected void onEnable() {
      this.leftTimer = 0;
      this.rightTimer = 0;
      this.release();
   }

   protected void onDisable() {
      this.release();
   }

   private void release() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.options != null) {
         mc.options.attackKey.setPressed(false);
         mc.options.useKey.setPressed(false);
      }
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if ((Boolean)this.inScreens.get() || mc.currentScreen == null) {
            String var2 = (String)this.leftMode.get();
            byte var3 = -1;
            switch (var2.hashCode()) {
               case 2255071:
                  if (var2.equals("Hold")) {
                     var3 = 0;
                  }
                  break;
               case 77378595:
                  if (var2.equals("Press")) {
                     var3 = 1;
                  }
            }

            switch (var3) {
               case 0:
                  mc.options.attackKey.setPressed(true);
                  break;
               case 1:
                  ++this.leftTimer;
                  if (this.leftTimer > this.leftDelay.getInt()) {
                     this.leftClick(mc);
                     this.leftTimer = 0;
                  }
            }

            var2 = (String)this.rightMode.get();
            var3 = -1;
            switch (var2.hashCode()) {
               case 2255071:
                  if (var2.equals("Hold")) {
                     var3 = 0;
                  }
                  break;
               case 77378595:
                  if (var2.equals("Press")) {
                     var3 = 1;
                  }
            }

            switch (var3) {
               case 0:
                  mc.options.useKey.setPressed(true);
                  break;
               case 1:
                  ++this.rightTimer;
                  if (this.rightTimer > this.rightDelay.getInt()) {
                     this.rightClick(mc);
                     this.rightTimer = 0;
                  }
            }

         }
      }
   }

   private void leftClick(MinecraftClient mc) {
      if (mc.attackCooldown == 10000) {
         mc.attackCooldown = 0;
      }

      mc.options.attackKey.setPressed(true);
      ((MinecraftAccessor)mc).n0client$startAttack();
      mc.options.attackKey.setPressed(false);
   }

   private void rightClick(MinecraftClient mc) {
      ((MinecraftAccessor)mc).n0client$startUseItem();
   }
}
