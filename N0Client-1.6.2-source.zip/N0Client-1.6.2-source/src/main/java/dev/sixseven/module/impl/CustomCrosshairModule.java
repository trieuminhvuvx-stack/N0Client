package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.render.nanovg.NVGRenderer;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ColorSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import dev.sixseven.util.Colors;

public class CustomCrosshairModule extends Module {
   private static final int HOT_PINK = -49508;
   public final ModeSetting style = (ModeSetting)this.addSetting(new ModeSetting("Style", "Crosshair shape", "Cross", new String[]{"Dot", "Cross", "Circle", "T-Shape", "Brackets", "Chevron", "67"}));
   public final SliderSetting size = (SliderSetting)this.addSetting(new SliderSetting("Size", "Overall crosshair size", (double)7.0F, (double)2.0F, (double)24.0F, (double)1.0F, "px"));
   public final SliderSetting thickness = (SliderSetting)this.addSetting(new SliderSetting("Thickness", "Line / dot thickness", (double)2.0F, (double)1.0F, (double)6.0F, (double)0.5F, "px"));
   public final SliderSetting gap = (SliderSetting)this.addSetting(new SliderSetting("Gap", "Center gap for line styles", (double)3.0F, (double)0.0F, (double)12.0F, (double)1.0F, "px"));
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Crosshair color", -49508));
   public final BooleanSetting rainbow = (BooleanSetting)this.addSetting(new BooleanSetting("Rainbow", "Cycle through the rainbow", false));
   public final BooleanSetting centerDot = (BooleanSetting)this.addSetting(new BooleanSetting("Center Dot", "Add a filled dot at the very center", false));
   public final BooleanSetting outline = (BooleanSetting)this.addSetting(new BooleanSetting("Outline", "Dark border for contrast on any background", true));
   public final BooleanSetting glow = (BooleanSetting)this.addSetting(new BooleanSetting("Glow", "Soft glow behind the crosshair", true));
   public final BooleanSetting hideVanilla = (BooleanSetting)this.addSetting(new BooleanSetting("Hide Vanilla", "Hide Minecraft's default crosshair", true));

   public CustomCrosshairModule() {
      super("CustomCrosshair", "Draws a custom crosshair", Category.MISC);
   }

   public boolean shouldHideVanilla() {
      return this.isEnabled() && (Boolean)this.hideVanilla.get();
   }

   private int resolveColor() {
      if ((Boolean)this.rainbow.get()) {
         float hue = (float)(System.nanoTime() % 3000000000L) / 3.0E9F;
         return -16777216 | Colors.hsvToRgb(hue, 0.85F, 1.0F) & 16777215;
      } else {
         return (Integer)this.color.get();
      }
   }

   public void render(NVGRenderer vg, float cx, float cy) {
      int col = this.resolveColor();
      int line = (Boolean)this.outline.get() ? -1342177280 : 0;
      float t = this.thickness.getFloat();
      float s = this.size.getFloat();
      float g = this.gap.getFloat();
      if ((Boolean)this.glow.get()) {
         vg.circleGlow(cx, cy, s + 2.0F, 6.0F, Colors.withAlpha(col, 0.45F));
      }

      String var9 = (String)this.style.get();
      byte var10 = -1;
      switch (var9.hashCode()) {
         case -1887427045:
            if (var9.equals("Chevron")) {
               var10 = 5;
            }
            break;
         case -1390943032:
            if (var9.equals("T-Shape")) {
               var10 = 2;
            }
            break;
         case 1729:
            if (var9.equals("67")) {
               var10 = 6;
            }
            break;
         case 68905:
            if (var9.equals("Dot")) {
               var10 = 0;
            }
            break;
         case 29314283:
            if (var9.equals("Brackets")) {
               var10 = 4;
            }
            break;
         case 65382432:
            if (var9.equals("Cross")) {
               var10 = 1;
            }
            break;
         case 2018617584:
            if (var9.equals("Circle")) {
               var10 = 3;
            }
      }

      switch (var10) {
         case 0:
            this.dot(vg, cx, cy, Math.max(1.5F, s * 0.35F), col, line);
            break;
         case 1:
            this.cross(vg, cx, cy, s, t, g, col, line, true, true);
            break;
         case 2:
            this.cross(vg, cx, cy, s, t, g, col, line, false, true);
            break;
         case 3:
            this.ring(vg, cx, cy, s, t, col, line);
            break;
         case 4:
            this.brackets(vg, cx, cy, s, t, g, col, line);
            break;
         case 5:
            if (line != 0) {
               vg.chevron(cx, cy + s * 0.15F, s + 2.0F, t + 2.0F, line, true);
            }

            vg.chevron(cx, cy + s * 0.15F, s, t, col, true);
            break;
         case 6:
            this.logo(vg, cx, cy, s, col);
            break;
         default:
            this.cross(vg, cx, cy, s, t, g, col, line, true, true);
      }

      if ((Boolean)this.centerDot.get() && !this.style.is("Dot") && !this.style.is("67")) {
         this.dot(vg, cx, cy, Math.max(1.2F, t * 0.8F), col, line);
      }

   }

   private void dot(NVGRenderer vg, float cx, float cy, float r, int col, int line) {
      if (line != 0) {
         vg.circle(cx, cy, r + 1.0F, line);
      }

      vg.circle(cx, cy, r, col);
   }

   private void ring(NVGRenderer vg, float cx, float cy, float r, float t, int col, int line) {
      if (line != 0) {
         vg.circleOutline(cx, cy, r, t + 2.0F, line);
      }

      vg.circleOutline(cx, cy, r, t, col);
   }

   private void cross(NVGRenderer vg, float cx, float cy, float len, float t, float g, int col, int line, boolean top, boolean bottom) {
      if (line != 0) {
         this.segments(vg, cx, cy, len, t + 2.0F, g, line, top, bottom);
      }

      this.segments(vg, cx, cy, len, t, g, col, top, bottom);
   }

   private void segments(NVGRenderer vg, float cx, float cy, float len, float t, float g, int argb, boolean top, boolean bottom) {
      vg.line(cx + g, cy, cx + g + len, cy, t, argb);
      vg.line(cx - g, cy, cx - g - len, cy, t, argb);
      if (top) {
         vg.line(cx, cy - g, cx, cy - g - len, t, argb);
      }

      if (bottom) {
         vg.line(cx, cy + g, cx, cy + g + len, t, argb);
      }

   }

   private void brackets(NVGRenderer vg, float cx, float cy, float len, float t, float g, int col, int line) {
      float arm = Math.max(2.0F, len * 0.5F);
      float d = len + g * 0.4F;
      if (line != 0) {
         this.drawBrackets(vg, cx, cy, d, arm, t + 2.0F, line);
      }

      this.drawBrackets(vg, cx, cy, d, arm, t, col);
   }

   private void drawBrackets(NVGRenderer vg, float cx, float cy, float d, float arm, float t, int argb) {
      vg.line(cx - d, cy - d, cx - d + arm, cy - d, t, argb);
      vg.line(cx - d, cy - d, cx - d, cy - d + arm, t, argb);
      vg.line(cx + d, cy - d, cx + d - arm, cy - d, t, argb);
      vg.line(cx + d, cy - d, cx + d, cy - d + arm, t, argb);
      vg.line(cx - d, cy + d, cx - d + arm, cy + d, t, argb);
      vg.line(cx - d, cy + d, cx - d, cy + d - arm, t, argb);
      vg.line(cx + d, cy + d, cx + d - arm, cy + d, t, argb);
      vg.line(cx + d, cy + d, cx + d, cy + d - arm, t, argb);
   }

   private void logo(NVGRenderer vg, float cx, float cy, float s, int col) {
      float font = s * 2.4F;
      float w = vg.textWidth("67", font);
      float tx = cx - w / 2.0F;
      vg.textGlow("67", tx, cy, font, Colors.withAlpha(-49508, 0.6F));
      vg.text("67", tx, cy, font, col);
   }
}
