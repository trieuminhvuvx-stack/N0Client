package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import dev.sixseven.settings.StringSetting;
import dev.sixseven.staff.StaffDetector;
import dev.sixseven.staff.StaffEntry;
import dev.sixseven.staff.StaffTracker;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class StaffListModule extends Module {
   public final ModeSetting detectBy = (ModeSetting)this.addSetting(new ModeSetting("Detect By", "How staff are recognised: the DonutSMP coloured star, a text rank prefix, or both", "Star + Rank", new String[]{"Star + Rank", "Star Only", "Rank Only", "Names Only"}));
   public final StringSetting staffNames = (StringSetting)this.addSetting(new StringSetting("Staff Names", "Extra known staff usernames (comma-separated) \u2014 always shown when online", "", 220, "e.g. Notch, jeb_"));
   public final StringSetting rankKeywords;
   public final StringSetting starSymbols;
   public final BooleanSetting fontIcons;
   public final BooleanSetting showRank;
   public final BooleanSetting showPing;
   public final BooleanSetting vanished;
   public final SliderSetting maxRows;
   public final ModeSetting alerts;
   public final BooleanSetting alertSound;
   public final StaffTracker tracker;

   public StaffListModule() {
      super("StaffList", "Lists online staff on the HUD (DonutSMP coloured-star detection)", Category.MISC);
      this.rankKeywords = (StringSetting)this.addSetting(new StringSetting("Rank Keywords", "Words in a name tag that mark staff (comma-separated), most senior first", StaffDetector.DEFAULT_RANK_KEYWORDS_STRING, 256, "owner, admin, mod\u2026"));
      this.starSymbols = (StringSetting)this.addSetting(new StringSetting("Star Symbols", "Marker glyphs that mean 'staff'. Paste the server's star here if detection misses", "\u2605\u2606\u2726\u2727\u272a\u2729\u272b\u272c\u272d\u272e\u272f\u2b50\u2730\u2742\u269d\u2734\u2735\u2736\u2737\u2738\u2739\u235f", 96, "\u2605 \u2726 \u2b50"));
      this.fontIcons = (BooleanSetting)this.addSetting(new BooleanSetting("Font Icons", "Also treat custom resource-pack icons (private-use glyphs) as staff stars", true));
      this.showRank = (BooleanSetting)this.addSetting(new BooleanSetting("Show Rank", "Show each staff member's rank label when the server exposes one", true));
      this.showPing = (BooleanSetting)this.addSetting(new BooleanSetting("Show Ping", "Show each staff member's latency", false));
      this.vanished = (BooleanSetting)this.addSetting(new BooleanSetting("Vanished Staff", "Include soft-vanished staff (spectator / hidden from tab), marked separately", true));
      this.maxRows = (SliderSetting)this.addSetting(new SliderSetting("Max Rows", "Most staff rows to show before collapsing into a '+N more' line", (double)6.0F, (double)1.0F, (double)20.0F, (double)1.0F));
      this.alerts = (ModeSetting)this.addSetting(new ModeSetting("Alerts", "Announce when a new staff member appears in your tab", "Toast", new String[]{"Toast", "Chat", "Off"}));
      this.alertSound = (BooleanSetting)this.addSetting(new BooleanSetting("Alert Sound", "Play a bell when a staff alert fires", true));
      this.tracker = new StaffTracker(this);
      this.rankKeywords.visibleWhen(this::usesRank);
      this.starSymbols.visibleWhen(this::usesStar);
      this.fontIcons.visibleWhen(this::usesStar);
      this.alertSound.visibleWhen(() -> !this.alerts.is("Off"));
   }

   private boolean usesStar() {
      return this.detectBy.is("Star + Rank") || this.detectBy.is("Star Only");
   }

   private boolean usesRank() {
      return this.detectBy.is("Star + Rank") || this.detectBy.is("Rank Only");
   }

   protected void onEnable() {
      this.tracker.reset();
   }

   protected void onDisable() {
      this.tracker.clear();
   }

   public void onTick() {
      this.tracker.tick();
   }

   public List<StaffEntry> staff() {
      return this.tracker.current();
   }

   public StaffDetector.DetectConfig detectConfig() {
      List<String> keywords = parseKeywords((String)this.rankKeywords.get());
      return new StaffDetector.DetectConfig((String)this.detectBy.get(), parseNames((String)this.staffNames.get()), keywords.isEmpty() ? StaffDetector.DEFAULT_RANK_KEYWORDS : keywords, (String)this.starSymbols.get(), (Boolean)this.fontIcons.get(), (Boolean)this.vanished.get());
   }

   public void onStaffAppear(StaffEntry e) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && !this.alerts.is("Off")) {
         String rank = e.rankLabel().isEmpty() ? "Staff" : e.rankLabel();
         String tail = e.vanished() ? " (vanished)" : "";
         if (this.alerts.is("Toast")) {
            if (N0Client.notifications() != null) {
               N0Client.notifications().pushInfo(rank + " " + e.name() + " online" + tail);
            }
         } else if (this.alerts.is("Chat")) {
            mc.player.sendMessage(Text.literal("\u00a7d[67] \u00a7f" + rank + " \u00a7b" + e.name() + "\u00a77 is online" + tail), false);
         }

         if ((Boolean)this.alertSound.get()) {
            mc.getSoundManager().play(PositionedSoundInstance.ui((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.5F, 0.6F));
         }

      }
   }

   private static Set<String> parseNames(String raw) {
      Set<String> out = new HashSet();

      for(String part : raw.split("[,\\s]+")) {
         if (!part.isEmpty()) {
            out.add(part.toLowerCase(Locale.ROOT));
         }
      }

      return out;
   }

   private static List<String> parseKeywords(String raw) {
      List<String> out = new ArrayList();

      for(String part : raw.split("[,\\s]+")) {
         String kw = part.trim().toLowerCase(Locale.ROOT);
         if (!kw.isEmpty()) {
            out.add(kw);
         }
      }

      return out;
   }
}
