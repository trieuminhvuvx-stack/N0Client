package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import dev.sixseven.settings.StringSetting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;

public class AutoTpaModule extends Module {
   public final ModeSetting mode = (ModeSetting)this.addSetting(new ModeSetting("Mode", "Which request to send.", "TPA", new String[]{"TPA", "TPAHere"}));
   public final StringSetting target = (StringSetting)this.addSetting(new StringSetting("Target", "Player to send the request to.", "", 32, "Steve"));
   public final SliderSetting delay = (SliderSetting)this.addSetting(new SliderSetting("Delay", "Time between requests \u2014 lower is faster.", (double)2000.0F, (double)250.0F, (double)10000.0F, (double)50.0F, "ms"));
   public final SliderSetting humanize = (SliderSetting)this.addSetting(new SliderSetting("Humanize", "Random +/- swing on each delay so the timing isn't a fixed, bot-like interval. 0 = off.", (double)25.0F, (double)0.0F, (double)60.0F, (double)5.0F, "%"));
   public final BooleanSetting notify = (BooleanSetting)this.addSetting(new BooleanSetting("Notify", "Show a notification each time a request is sent.", false));
   private long nextSendAtMs = -1L;
   private String lastSent;

   public AutoTpaModule() {
      super("AutoTPA", "Spams TPA requests at a target on a humanized timer.", Category.MISC);
   }

   protected void onEnable() {
      if (((String)this.target.get()).trim().isEmpty()) {
         N0Client.notifications().pushInfo("AutoTPA \u00b7 set a Target first");
      }

      this.lastSent = null;
      this.nextSendAtMs = 0L;
   }

   protected void onDisable() {
      this.nextSendAtMs = -1L;
   }

   public void onTick() {
      if (this.nextSendAtMs >= 0L) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null && mc.player.networkHandler != null) {
            if (System.currentTimeMillis() >= this.nextSendAtMs) {
               String name = ((String)this.target.get()).trim();
               if (name.isEmpty()) {
                  this.nextSendAtMs = this.scheduleNext();
               } else {
                  String var10000 = this.mode.is("TPAHere") ? "tpahere " : "tpa ";
                  String cmd = var10000 + name;
                  mc.player.networkHandler.sendChatCommand(cmd);
                  this.lastSent = cmd;
                  if ((Boolean)this.notify.get()) {
                     N0Client.notifications().pushInfo("AutoTPA \u00b7 /" + cmd);
                  }

                  this.nextSendAtMs = this.scheduleNext();
               }
            }
         }
      }
   }

   public String lastSent() {
      return this.lastSent;
   }

   private long scheduleNext() {
      double base = (Double)this.delay.get();
      double j = (Double)this.humanize.get() / (double)100.0F;
      double factor = j <= (double)0.0F ? (double)1.0F : (double)1.0F + (ThreadLocalRandom.current().nextDouble() * (double)2.0F - (double)1.0F) * j;
      long wait = Math.max(0L, Math.round(base * factor));
      return System.currentTimeMillis() + wait;
   }
}
