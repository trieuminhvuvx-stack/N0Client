package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public class TriggerbotModule extends Module {
   public final SliderSetting minDelay = (SliderSetting)this.addSetting(new SliderSetting("Min Delay", "", (double)9.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final SliderSetting maxDelay = (SliderSetting)this.addSetting(new SliderSetting("Max Delay", "", (double)11.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final BooleanSetting onlyItem = (BooleanSetting)this.addSetting(new BooleanSetting("Only Item", "", false));
   public final ModeSetting itemFilter = (ModeSetting)this.addSetting(new ModeSetting("Item Filter", "", "Sword", new String[]{"Sword", "Axe", "Hand"}));
   public final BooleanSetting onlyCrit = (BooleanSetting)this.addSetting(new BooleanSetting("Only Crit", "", false));
   public final BooleanSetting checkShield = (BooleanSetting)this.addSetting(new BooleanSetting("Check Shield", "", false));
   private final Random random = new Random();
   private int tickCounter;
   private int currentDelay = 10;

   public TriggerbotModule() {
      super("Triggerbot", "Auto-attacks entities on crosshair", Category.COMBAT);
   }

   protected void onEnable() {
      this.tickCounter = 0;
      this.randomizeDelay();
   }

   protected void onDisable() {
      this.tickCounter = 0;
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null && client.currentScreen == null) {
         if (client.crosshairTarget != null && client.crosshairTarget.getType() == Type.ENTITY) {
            Entity target = ((EntityHitResult)client.crosshairTarget).getEntity();
            if (target instanceof LivingEntity && target != client.player) {
               if ((Boolean)this.onlyItem.get()) {
                  if (this.itemFilter.is("Sword") && !this.isSword(client.player.getMainHandStack().getItem())) {
                     return;
                  }

                  if (this.itemFilter.is("Axe") && !(client.player.getMainHandStack().getItem() instanceof AxeItem)) {
                     return;
                  }

                  if (this.itemFilter.is("Hand") && !client.player.getMainHandStack().isEmpty()) {
                     return;
                  }
               }

               if (!(Boolean)this.onlyCrit.get() || !client.player.isOnGround() && !(client.player.fallDistance <= (double)0.0F)) {
                  if ((Boolean)this.checkShield.get() && target instanceof PlayerEntity) {
                     PlayerEntity targetPlayer = (PlayerEntity)target;
                     if (targetPlayer.isBlocking()) {
                        return;
                     }
                  }

                  if (!(client.player.getAttackCooldownProgress(0.5F) < 1.0F)) {
                     ++this.tickCounter;
                     if (this.tickCounter >= this.currentDelay) {
                        client.interactionManager.attackEntity(client.player, target);
                        client.player.swingHand(Hand.MAIN_HAND);
                        this.tickCounter = 0;
                        this.randomizeDelay();
                     }
                  }
               }
            }
         } else {
            this.tickCounter = 0;
         }

      }
   }

   private boolean isSword(Item item) {
      return item == Items.WOODEN_SWORD || item == Items.STONE_SWORD || item == Items.IRON_SWORD || item == Items.GOLDEN_SWORD || item == Items.DIAMOND_SWORD || item == Items.NETHERITE_SWORD;
   }

   private void randomizeDelay() {
      int min = this.minDelay.getInt();
      int max = this.maxDelay.getInt();
      if (max < min) {
         max = min;
      }

      this.currentDelay = min + (max > min ? this.random.nextInt(max - min + 1) : 0);
   }
}
