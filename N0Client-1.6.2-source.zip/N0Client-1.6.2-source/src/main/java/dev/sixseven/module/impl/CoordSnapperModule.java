package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.KeybindSetting;
import dev.sixseven.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;

public class CoordSnapperModule extends Module {
   public final ModeSetting format = (ModeSetting)this.addSetting(new ModeSetting("Format", "Clipboard format.", "X Y Z", new String[]{"X Y Z", "JSON", "Command"}));
   public final ModeSetting target = (ModeSetting)this.addSetting(new ModeSetting("Target", "Which coordinates to copy.", "Looked-at Block", new String[]{"Looked-at Block", "Player"}));
   public final KeybindSetting copyKey = (KeybindSetting)this.addSetting(new KeybindSetting("Copy Key", "Press to copy the coordinates.", -1));
   public final BooleanSetting notify = (BooleanSetting)this.addSetting(new BooleanSetting("Notify", "Show a confirmation when copied.", true));
   private String lastCopied = "";

   public CoordSnapperModule() {
      super("CoordSnapper", "Copies looked-at coordinates with one key.", Category.MISC);
   }

   public String lastCopied() {
      return this.lastCopied;
   }

   public boolean onKeyPress(int keyCode) {
      if (!this.copyKey.matches(keyCode)) {
         return false;
      } else {
         this.snap();
         return true;
      }
   }

   private void snap() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         BlockPos pos = this.resolvePos(mc);
         if (pos == null) {
            if ((Boolean)this.notify.get()) {
               N0Client.notifications().pushInfo("CoordSnapper \u00b7 no block in view");
            }

         } else {
            String var4 = (String)this.format.get();
            byte var5 = -1;
            switch (var4.hashCode()) {
               case -1679919317:
                  if (var4.equals("Command")) {
                     var5 = 1;
                  }
                  break;
               case 2286824:
                  if (var4.equals("JSON")) {
                     var5 = 0;
                  }
            }

            String var10000;
            switch (var5) {
               case 0 -> var10000 = "{\"x\": " + pos.getX() + ", \"y\": " + pos.getY() + ", \"z\": " + pos.getZ() + "}";
               case 1 -> var10000 = "/tp " + pos.getX() + " " + pos.getY() + " " + pos.getZ();
               default -> var10000 = pos.getX() + " " + pos.getY() + " " + pos.getZ();
            }

            String text = var10000;
            mc.keyboard.setClipboard(text);
            this.lastCopied = text;
            if ((Boolean)this.notify.get()) {
               N0Client.notifications().pushInfo("Copied \u00b7 " + text);
            }

         }
      }
   }

   private BlockPos resolvePos(MinecraftClient mc) {
      if (this.target.is("Player")) {
         return mc.player.getBlockPos();
      } else {
         HitResult hit = mc.crosshairTarget;
         if (hit instanceof BlockHitResult) {
            BlockHitResult block = (BlockHitResult)hit;
            if (hit.getType() == Type.BLOCK) {
               return block.getBlockPos();
            }
         }

         return null;
      }
   }
}
