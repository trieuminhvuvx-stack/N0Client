package dev.sixseven.module.impl;

import dev.sixseven.N0Client;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.ColorSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;
import dev.sixseven.util.Colors;
import java.util.Locale;

public class CustomGlintModule extends Module {
   public final ModeSetting style = (ModeSetting)this.addSetting(new ModeSetting("Style", "Glint texture. Default recolors the vanilla foil; the rest are custom patterns", "Default", new String[]{"Default", "Ender", "Void", "Galaxy", "Toxic", "Amethyst", "Cyber", "Solar", "Prismatic", "Abyss"}));
   public final ModeSetting mode = (ModeSetting)this.addSetting(new ModeSetting("Mode", "Where the glint color comes from", "Solid", new String[]{"Solid", "Rainbow", "Theme"}));
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Glint color", -49508));
   public final SliderSetting strength = (SliderSetting)this.addSetting(new SliderSetting("Strength", "Glint intensity", (double)60.0F, (double)0.0F, (double)100.0F, (double)5.0F, "%"));
   public final SliderSetting speed = (SliderSetting)this.addSetting(new SliderSetting("Speed", "Rainbow cycle speed", (double)100.0F, (double)10.0F, (double)300.0F, (double)10.0F, "%"));

   public CustomGlintModule() {
      super("CustomGlint", "Recolors or restyles the enchantment glint", Category.MISC);
      this.mode.visibleWhen(() -> this.style.is("Default"));
      this.color.visibleWhen(() -> this.style.is("Default") && this.mode.is("Solid"));
      this.speed.visibleWhen(() -> this.style.is("Default") && this.mode.is("Rainbow"));
   }

   public boolean isActive() {
      return this.isEnabled();
   }

   public boolean usesTexture() {
      return !this.style.is("Default");
   }

   public String textureName() {
      return ((String)this.style.get()).toLowerCase(Locale.ROOT);
   }

   public float strengthUnit() {
      return this.strength.getFloat() / 100.0F;
   }

   public int glintColor() {
      String var2 = (String)this.mode.get();
      int r = -1;
      switch (var2.hashCode()) {
         case -1656737386:
            if (var2.equals("Rainbow")) {
               r = 0;
            }
            break;
         case 80774569:
            if (var2.equals("Theme")) {
               r = 1;
            }
      }

      int var10000;
      switch (r) {
         case 0 -> var10000 = this.rainbow();
         case 1 -> var10000 = N0Client.themes().current().accent();
         default -> var10000 = (Integer)this.color.get();
      }

      int base = var10000;
      float s = this.strength.getFloat() / 100.0F;
      r = Math.round((float)Colors.red(base) * s);
      int g = Math.round((float)Colors.green(base) * s);
      int b = Math.round((float)Colors.blue(base) * s);
      return Colors.rgb(r, g, b);
   }

   private int rainbow() {
      double seconds = (double)(System.nanoTime() % 1000000000000L) / (double)1.0E9F;
      double hue = seconds * (double)36.0F * (double)(this.speed.getFloat() / 100.0F) % (double)360.0F;
      return Colors.hsvToRgb((float)hue, 0.85F, 1.0F);
   }
}
