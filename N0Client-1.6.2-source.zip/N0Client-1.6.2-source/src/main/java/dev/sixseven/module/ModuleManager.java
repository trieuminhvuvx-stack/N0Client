package dev.sixseven.module;

import dev.sixseven.module.impl.AimAssistModule;
import dev.sixseven.module.impl.AnchorMacroModule;
import dev.sixseven.module.impl.ArmorTrimHiderModule;
import dev.sixseven.module.impl.AutoClickerModule;
import dev.sixseven.module.impl.AutoCrystalModule;
import dev.sixseven.module.impl.AutoInventoryTotemModule;
import dev.sixseven.module.impl.AutoTotemModule;
import dev.sixseven.module.impl.AutoTpaModule;
import dev.sixseven.module.impl.AutoWalkModule;
import dev.sixseven.module.impl.BlockEntityEspModule;
import dev.sixseven.module.impl.BlockEspModule;
import dev.sixseven.module.impl.ChatMacroModule;
import dev.sixseven.module.impl.ChunkFinderModule;
import dev.sixseven.module.impl.CoordSnapperModule;
import dev.sixseven.module.impl.CustomAccessoriesModule;
import dev.sixseven.module.impl.CustomCrosshairModule;
import dev.sixseven.module.impl.CustomFovModule;
import dev.sixseven.module.impl.CustomGlintModule;
import dev.sixseven.module.impl.DebugHoleEspModule;
import dev.sixseven.module.impl.DoubleAnchorModule;
import dev.sixseven.module.impl.ElytraSwapModule;
import dev.sixseven.module.impl.FakePayModule;
import dev.sixseven.module.impl.FakeRolesModule;
import dev.sixseven.module.impl.FakeStatsModule;
import dev.sixseven.module.impl.FastUseModule;
import dev.sixseven.module.impl.FreeLookModule;
import dev.sixseven.module.impl.FreecamModule;
import dev.sixseven.module.impl.FullbrightModule;
import dev.sixseven.module.impl.GambleRiggerModule;
import dev.sixseven.module.impl.HitBoxModule;
import dev.sixseven.module.impl.HitParticlesModule;
import dev.sixseven.module.impl.HoverTotemModule;
import dev.sixseven.module.impl.JumpCirclesModule;
import dev.sixseven.module.impl.MaceBomberModule;
import dev.sixseven.module.impl.MaceSwapModule;
import dev.sixseven.module.impl.MobEspModule;
import dev.sixseven.module.impl.MotionBlurModule;
import dev.sixseven.module.impl.NameProtectModule;
import dev.sixseven.module.impl.NameTagsModule;
import dev.sixseven.module.impl.PlayerEspModule;
import dev.sixseven.module.impl.RegionMapModule;
import dev.sixseven.module.impl.ShieldBreakerModule;
import dev.sixseven.module.impl.SkinProtectModule;
import dev.sixseven.module.impl.SpawnerNametagsModule;
import dev.sixseven.module.impl.SpawnerProtectModule;
import dev.sixseven.module.impl.StaffListModule;
import dev.sixseven.module.impl.StorageEspModule;
import dev.sixseven.module.impl.SwingSpeedModule;
import dev.sixseven.module.impl.TriggerbotModule;
import dev.sixseven.module.impl.WeatherNotifierModule;
import dev.sixseven.module.impl.ZoomModule;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.Setting;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public class ModuleManager {
   private final List<Module> modules = new ArrayList();
   private final Map<Category, List<Module>> byCategory = new LinkedHashMap();
   public final Modules.ClickGuiModule clickGui;
   public final Modules.HudModule hud;
   public final Modules.SpotifyModule spotify;
   public final Modules.BlockOutlineModule blockOutline;
   public final Modules.SusChunkFinderModule susChunkFinder;
   public FullbrightModule fullbright;
   public AutoWalkModule autoWalk;
   public WeatherNotifierModule weatherNotifier;
   public SwingSpeedModule swingSpeed;
   public StorageEspModule storageEsp;
   public BlockEspModule blockEsp;
   public AutoTotemModule autoTotem;
   public MaceSwapModule maceSwap;
   public AnchorMacroModule anchorMacro;
   public AutoCrystalModule autoCrystal;
   public HitBoxModule hitBox;
   public ElytraSwapModule elytraSwap;
   public HoverTotemModule hoverTotem;
   public ShieldBreakerModule shieldBreaker;
   public TriggerbotModule triggerbot;
   public AimAssistModule aimAssist;
   public DoubleAnchorModule doubleAnchor;
   public MaceBomberModule maceBomber;
   public NameProtectModule nameProtect;
   public SkinProtectModule skinProtect;
   public NameTagsModule nameTags;
   public FastUseModule fastUse;
   public AutoInventoryTotemModule autoInventoryTotem;
   public PlayerEspModule playerEsp;
   public MobEspModule mobEsp;
   public BlockEntityEspModule blockEntityEsp;
   public SpawnerNametagsModule spawnerNametags;
   public DebugHoleEspModule debugHoleEsp;
   public FreecamModule freecam;
   public AutoTpaModule autoTpa;
   public JumpCirclesModule jumpCircles;
   public CustomCrosshairModule customCrosshair;
   public ZoomModule zoom;
   public CustomFovModule customFov;
   public HitParticlesModule hitParticles;
   public MotionBlurModule motionBlur;
   public CustomGlintModule customGlint;
   public CustomAccessoriesModule customAccessories;
   public ChunkFinderModule chunkFinder;
   public FreeLookModule freeLook;
   public AutoClickerModule autoClicker;
   public CoordSnapperModule coordSnapper;
   public RegionMapModule regionMap;
   public ChatMacroModule chatMacro;
   public FakePayModule fakePay;
   public FakeStatsModule fakeStats;
   public FakeRolesModule fakeRoles;
   public StaffListModule staffList;
   public ArmorTrimHiderModule armorTrimHider;
   public SpawnerProtectModule spawnerProtect;
   public GambleRiggerModule gambleRigger;
   private Runnable openGuiAction = () -> {
   };
   private BiConsumer<Module, Boolean> toggleListener = (m, e) -> {
   };

   public ModuleManager() {
      for(Category category : Category.values()) {
         this.byCategory.put(category, new ArrayList());
      }

      this.susChunkFinder = new Modules.SusChunkFinderModule();
      this.registerPlaceholders();
      this.register(this.blockOutline = new Modules.BlockOutlineModule());
      this.register(this.hitParticles = new HitParticlesModule());
      this.register(this.customAccessories = new CustomAccessoriesModule());
      this.register(this.motionBlur = new MotionBlurModule());
      this.register(this.hud = new Modules.HudModule());
      this.register(this.spotify = new Modules.SpotifyModule());
      this.register(this.chatMacro = new ChatMacroModule());
      this.ph("ConfigShare", "Import/export configs via codes", Category.CLIENT, new BooleanSetting("Include HUD Layout", "Share HUD positions too", true));
      this.register(this.swingSpeed = new SwingSpeedModule());
      this.register(this.jumpCircles = new JumpCirclesModule());
      this.register(this.clickGui = new Modules.ClickGuiModule());
   }

   private void registerPlaceholders() {
      this.register(this.autoTotem = new AutoTotemModule());
      this.register(this.autoCrystal = new AutoCrystalModule());
      this.register(this.anchorMacro = new AnchorMacroModule());
      this.register(this.doubleAnchor = new DoubleAnchorModule());
      this.register(this.autoInventoryTotem = new AutoInventoryTotemModule());
      this.register(this.aimAssist = new AimAssistModule());
      this.register(this.maceSwap = new MaceSwapModule());
      this.register(this.hitBox = new HitBoxModule());
      this.register(this.elytraSwap = new ElytraSwapModule());
      this.register(this.hoverTotem = new HoverTotemModule());
      this.register(this.shieldBreaker = new ShieldBreakerModule());
      this.register(this.triggerbot = new TriggerbotModule());
      this.register(this.maceBomber = new MaceBomberModule());
      this.register(this.skinProtect = new SkinProtectModule());
      this.register(this.nameProtect = new NameProtectModule());
      this.register(this.freecam = new FreecamModule());
      this.register(this.autoTpa = new AutoTpaModule());
      this.register(this.autoClicker = new AutoClickerModule());
      this.register(this.fastUse = new FastUseModule());
      this.register(this.nameTags = new NameTagsModule());
      this.register(this.fakePay = new FakePayModule());
      this.register(this.weatherNotifier = new WeatherNotifierModule());
      this.register(this.fakeStats = new FakeStatsModule());
      this.register(this.fakeRoles = new FakeRolesModule());
      this.register(this.armorTrimHider = new ArmorTrimHiderModule());
      this.register(this.customCrosshair = new CustomCrosshairModule());
      this.ph("Media/StaffNames/Icons", "Marks media & staff players with icons", Category.MISC, new BooleanSetting("Media", "Show media icons", true), new BooleanSetting("Staff", "Show staff icons", true), new ModeSetting("Position", "Icon position", "Prefix", new String[]{"Prefix", "Suffix"}));
      this.register(this.staffList = new StaffListModule());
      this.register(this.customGlint = new CustomGlintModule());
      this.register(this.customFov = new CustomFovModule());
      this.register(this.coordSnapper = new CoordSnapperModule());
      this.register(this.autoWalk = new AutoWalkModule());
      this.register(this.zoom = new ZoomModule());
      this.register(this.freeLook = new FreeLookModule());
      this.register(this.spawnerProtect = new SpawnerProtectModule());
      this.register(this.gambleRigger = new GambleRiggerModule());
      this.register(this.blockEsp = new BlockEspModule());
      this.register(this.storageEsp = new StorageEspModule());
      this.register(this.blockEntityEsp = new BlockEntityEspModule());
      this.register(this.debugHoleEsp = new DebugHoleEspModule());
      this.register(this.fullbright = new FullbrightModule());
      this.register(this.playerEsp = new PlayerEspModule());
      this.register(this.mobEsp = new MobEspModule());
      this.register(this.spawnerNametags = new SpawnerNametagsModule());
      this.register(this.susChunkFinder);
      this.register(this.chunkFinder = new ChunkFinderModule());
      this.register(this.regionMap = new RegionMapModule());
   }

   private void ph(String name, String description, Category category, Setting<?>... settings) {
      this.register(new Modules.Placeholder(name, description, category, settings));
   }

   public void register(Module module) {
      this.modules.add(module);
      ((List)this.byCategory.get(module.getCategory())).add(module);
      module.setToggleCallback(this::notifyToggle);
   }

   public List<Module> all() {
      return this.modules;
   }

   public List<Module> inCategory(Category category) {
      return (List)this.byCategory.get(category);
   }

   public void setOpenGuiAction(Runnable action) {
      this.openGuiAction = action;
   }

   public void setToggleListener(BiConsumer<Module, Boolean> listener) {
      this.toggleListener = listener;
   }

   public void notifyToggle(Module module, boolean enabled) {
      this.toggleListener.accept(module, enabled);
   }

   public boolean onKeyPressed(int keyCode) {
      if (this.clickGui.getKeybind().matches(keyCode)) {
         this.openGuiAction.run();
         return true;
      } else {
         boolean handled = false;

         for(Module module : this.modules) {
            if (module != this.clickGui && module.getKeybind().matches(keyCode)) {
               module.toggle();
               handled = true;
            }
         }

         for(Module module : this.modules) {
            if (module.isEnabled() && module.onKeyPress(keyCode)) {
               handled = true;
            }
         }

         return handled;
      }
   }

   public void onTick() {
      for(Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() != Category.COMBAT) {
            module.onTick();
         }
      }

   }

   public void onCombatTick() {
      for(Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() == Category.COMBAT) {
            module.onTick();
         }
      }

   }
}
