package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Stream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.trim.ArmorTrim;
import net.minecraft.item.equipment.trim.ArmorTrimMaterial;
import net.minecraft.item.equipment.trim.ArmorTrimPattern;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import org.jetbrains.annotations.Nullable;

public class ArmorTrimHiderModule extends Module {
   public final ModeSetting mode = (ModeSetting)this.addSetting(new ModeSetting("Mode", "Hide wipes worn trims; Random gives every piece a random one", "Hide", new String[]{"Hide", "Random"}));
   public final BooleanSetting ownArmor = (BooleanSetting)this.addSetting(new BooleanSetting("Own Armor", "Also affect your own worn armor (F5 / inventory)", true));
   private DynamicRegistryManager cachedAccess;
   private final List<RegistryEntry<ArmorTrimMaterial>> materials = new ArrayList();
   private final List<RegistryEntry<ArmorTrimPattern>> patterns = new ArrayList();

   public ArmorTrimHiderModule() {
      super("ArmorTrimHider", "Hides or randomizes worn armor trims", Category.MISC);
   }

   public boolean affectsOwn() {
      return (Boolean)this.ownArmor.get();
   }

   public @Nullable ArmorTrim mapTrim(ItemStack stack, @Nullable ArmorTrim original) {
      if (this.mode.is("Random")) {
         ArmorTrim random = this.randomTrim(stack);
         return random != null ? random : original;
      } else {
         return null;
      }
   }

   private @Nullable ArmorTrim randomTrim(ItemStack stack) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null) {
         return null;
      } else {
         DynamicRegistryManager access = mc.world.getRegistryManager();
         if (access != this.cachedAccess) {
            this.rebuildCache(access);
         }

         if (!this.materials.isEmpty() && !this.patterns.isEmpty()) {
            Random rng = new Random((long)stack.getItem().getTranslationKey().hashCode());
            RegistryEntry<ArmorTrimMaterial> material = (RegistryEntry)this.materials.get(rng.nextInt(this.materials.size()));
            RegistryEntry<ArmorTrimPattern> pattern = (RegistryEntry)this.patterns.get(rng.nextInt(this.patterns.size()));
            return new ArmorTrim(material, pattern);
         } else {
            return null;
         }
      }
   }

   private void rebuildCache(DynamicRegistryManager access) {
      this.cachedAccess = access;
      this.materials.clear();
      this.patterns.clear();

      try {
         Stream var10000 = access.getOrThrow(RegistryKeys.TRIM_MATERIAL).streamEntries();
         List var10001 = this.materials;
         Objects.requireNonNull(var10001);
         var10000.forEach(var10001::add);
         var10000 = access.getOrThrow(RegistryKeys.TRIM_PATTERN).streamEntries();
         var10001 = this.patterns;
         Objects.requireNonNull(var10001);
         var10000.forEach(var10001::add);
      } catch (Exception var3) {
         this.materials.clear();
         this.patterns.clear();
      }

   }

   protected void onDisable() {
      this.cachedAccess = null;
      this.materials.clear();
      this.patterns.clear();
   }
}
