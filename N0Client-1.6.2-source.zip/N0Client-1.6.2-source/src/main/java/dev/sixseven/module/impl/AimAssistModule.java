package dev.sixseven.module.impl;

import dev.sixseven.module.AimAssistCompute;
import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ModeSetting;
import dev.sixseven.settings.SliderSetting;

public class AimAssistModule extends Module {
   public final SliderSetting range = (SliderSetting)this.addSetting(new SliderSetting("Range", "Assist any target within this distance", (double)4.0F, (double)1.0F, (double)8.0F, (double)0.5F, "m"));
   public final SliderSetting speed = (SliderSetting)this.addSetting(new SliderSetting("Speed", "How fast the aim is pulled (higher = snappier)", (double)4.0F, (double)1.0F, (double)10.0F, (double)1.0F));
   public final SliderSetting smoothness = (SliderSetting)this.addSetting(new SliderSetting("Smoothness", "How eased / human the pull is (higher = smoother)", (double)6.0F, (double)1.0F, (double)10.0F, (double)1.0F));
   public final ModeSetting targetPart = (ModeSetting)this.addSetting(new ModeSetting("Target", "Which part of the target to aim at", "Body", new String[]{"Head", "Body", "Feet", "Nearest"}));
   public final SliderSetting fov = (SliderSetting)this.addSetting(new SliderSetting("FOV", "Only assist within this facing cone (180 = all around)", (double)180.0F, (double)10.0F, (double)180.0F, (double)5.0F, "\u00b0"));
   public final BooleanSetting vertical = (BooleanSetting)this.addSetting(new BooleanSetting("Vertical", "Also correct pitch (up/down), not just yaw", true));
   public final BooleanSetting players = (BooleanSetting)this.addSetting(new BooleanSetting("Players", "Target other players", true));
   public final BooleanSetting hostiles = (BooleanSetting)this.addSetting(new BooleanSetting("Hostiles", "Target hostile mobs", false));
   public final BooleanSetting passive = (BooleanSetting)this.addSetting(new BooleanSetting("Passive", "Target passive mobs", false));
   public final BooleanSetting invisibles = (BooleanSetting)this.addSetting(new BooleanSetting("Invisibles", "Also target invisible entities", false));
   public final BooleanSetting wallCheck = (BooleanSetting)this.addSetting(new BooleanSetting("Wall Check", "Only assist targets you can actually see", false));
   public final BooleanSetting alwaysActive = (BooleanSetting)this.addSetting(new BooleanSetting("Always Active", "Assist all the time \u2014 off = only while attacking (holding left-click)", true));
   public final BooleanSetting sticky = (BooleanSetting)this.addSetting(new BooleanSetting("Sticky Target", "Keep one target until it leaves range", true));
   private final AimAssistCompute logic;

   public AimAssistModule() {
      super("AimAssist", "Legit aim assist \u2014 smoothly pulls toward targets in range", Category.COMBAT);
      // The computation logic previously lived in an encrypted, license-gated class
      // (dev.sixseven.secured.AimAssistLogic) that is not part of the jar; without it
      // the module is a no-op. Implement AimAssistCompute and assign it here to enable.
      this.logic = null;
   }

   public void onTick() {
   }

   protected void onDisable() {
      if (this.logic != null) {
         this.logic.reset();
      }

   }

   public double[] computePixels(double dt, double userDX, double userDY) {
      return this.logic == null ? null : this.logic.computePixels(this, dt, userDX, userDY);
   }
}
