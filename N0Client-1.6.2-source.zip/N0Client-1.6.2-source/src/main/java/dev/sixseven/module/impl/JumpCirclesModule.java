package dev.sixseven.module.impl;

import dev.sixseven.module.Category;
import dev.sixseven.module.Module;
import dev.sixseven.settings.BooleanSetting;
import dev.sixseven.settings.ColorSetting;
import dev.sixseven.settings.SliderSetting;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.math.random.Random;

public class JumpCirclesModule extends Module {
   public final SliderSetting size = (SliderSetting)this.addSetting(new SliderSetting("Size", "Decal scale (1.0 = one block wide)", (double)1.0F, (double)0.5F, (double)3.0F, 0.1, "x"));
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Decal color (alpha is animated)", -38476));
   public final SliderSetting lifetime = (SliderSetting)this.addSetting(new SliderSetting("Lifetime", "How long a 67 stays visible", (double)1.5F, (double)0.5F, (double)4.0F, 0.1, "s"));
   public final BooleanSetting rainbow = (BooleanSetting)this.addSetting(new BooleanSetting("Rainbow", "Cycle the color through the rainbow", false));
   public final BooleanSetting shockwave = (BooleanSetting)this.addSetting(new BooleanSetting("Shockwave", "Expanding ring on spawn", true));
   public final BooleanSetting particles = (BooleanSetting)this.addSetting(new BooleanSetting("Particles", "Drifting dust motes on jump", true));
   public final SliderSetting maxCircles = (SliderSetting)this.addSetting(new SliderSetting("Max", "Max simultaneous decals (oldest drops first)", (double)10.0F, (double)1.0F, (double)30.0F, (double)1.0F));
   private final Deque<JumpCircle> circles = new ArrayDeque();
   private int spawnCounter;

   public JumpCirclesModule() {
      super("67JumpCircles", "Stamps a glowing 67 on the ground when you jump", Category.CLIENT);
   }

   public Deque<JumpCircle> circles() {
      return this.circles;
   }

   protected void onDisable() {
      this.clear();
   }

   public void clear() {
      this.circles.clear();
   }

   public int baseRgb() {
      return (Integer)this.color.get() & 16777215;
   }

   public void onPlayerJump(ClientPlayerEntity player) {
      if (this.isEnabled()) {
         double x = player.getX();
         double y = player.getY();
         double z = player.getZ();
         float yLift = 0.01F + (float)(this.spawnCounter % 8) * 0.001F;
         ++this.spawnCounter;
         this.circles.addLast(new JumpCircle(x, y, z, player.getYaw(), yLift, System.nanoTime()));
         int max = Math.max(1, this.maxCircles.getInt());

         while(this.circles.size() > max) {
            this.circles.removeFirst();
         }

         if ((Boolean)this.particles.get()) {
            this.spawnParticles(player);
         }

      }
   }

   private void spawnParticles(ClientPlayerEntity player) {
      Random random = player.getRandom();
      int rgb = this.baseRgb();

      for(int i = 0; i < 10; ++i) {
         double angle = random.nextDouble() * Math.PI * (double)2.0F;
         double dist = 0.15 + random.nextDouble() * 0.45;
         player.getEntityWorld().addParticleClient(new DustParticleEffect(rgb, 0.9F), player.getX() + Math.cos(angle) * dist, player.getY() + 0.05, player.getZ() + Math.sin(angle) * dist, (double)0.0F, 0.6 + random.nextDouble() * 0.4, (double)0.0F);
      }

   }

   public static final class JumpCircle {
      public final double x;
      public final double y;
      public final double z;
      public final float yawDegrees;
      public final float yLift;
      public final long spawnNanos;

      JumpCircle(double x, double y, double z, float yawDegrees, float yLift, long spawnNanos) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.yawDegrees = yawDegrees;
         this.yLift = yLift;
         this.spawnNanos = spawnNanos;
      }

      public float ageSeconds(long nowNanos) {
         return (float)(nowNanos - this.spawnNanos) / 1.0E9F;
      }
   }
}
